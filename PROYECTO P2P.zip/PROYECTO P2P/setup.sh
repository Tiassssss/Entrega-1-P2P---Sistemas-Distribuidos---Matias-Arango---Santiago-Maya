#!/bin/bash

# Script de configuración para el proyecto P2P

echo "=== Configurando Proyecto P2P ==="

# Crear directorios necesarios
echo "Creando directorios..."
mkdir -p logs
mkdir -p shared_files

# Instalar dependencias
echo "Instalando dependencias Python..."
pip install -r requirements.txt

# Generar archivos protobuf
echo "Generando archivos protobuf..."
python -m grpc_tools.protoc \
    --proto_path=src/pservidor/rpc_server/ \
    --python_out=src/pservidor/rpc_server/ \
    --grpc_python_out=src/pservidor/rpc_server/ \
    src/pservidor/rpc_server/p2p.proto

# Corregir imports en archivos generados
echo "Corrigiendo imports en archivos protobuf..."
if [ -f "src/pservidor/rpc_server/p2p_pb2_grpc.py" ]; then
    sed -i 's/import p2p_pb2 as p2p__pb2/from . import p2p_pb2 as p2p__pb2/g' src/pservidor/rpc_server/p2p_pb2_grpc.py
fi

# Crear archivos de ejemplo
echo "Creando archivos de ejemplo..."
echo "Archivo de ejemplo 1" > shared_files/ejemplo1.txt
echo "Contenido de prueba para el archivo 2" > shared_files/ejemplo2.txt
echo "Este es un archivo de test más largo con más contenido para probar la transferencia de archivos en el sistema P2P" > shared_files/test_largo.txt

# Crear configuraciones adicionales para múltiples peers
echo "Creando configuraciones adicionales..."

# Peer 2
cat > src/config/peer2_config.json << 'EOF'
{
    "peer_id": "peer_002",
    "network": {
        "listen_ip": "0.0.0.0",
        "listen_port": 8082,
        "rpc_port": 8083,
        "max_connections": 50
    },
    "storage": {
        "shared_directory": "./shared_files2",
        "max_file_size": "100MB",
        "allowed_extensions": [".pdf", ".txt", ".jpg", ".png", ".docx", ".zip"]
    },
    "peers": {
        "bootstrap_peers": [
            "http://127.0.0.1:8080"
        ],
        "backup_peers": [
            "http://127.0.0.1:8080"
        ]
    },
    "security": {
        "enable_auth": false,
        "api_key": null
    },
    "logging": {
        "level": "INFO",
        "file": "logs/peer2.log"
    }
}
EOF

# Peer 3
cat > src/config/peer3_config.json << 'EOF'
{
    "peer_id": "peer_003",
    "network": {
        "listen_ip": "0.0.0.0",
        "listen_port": 8084,
        "rpc_port": 8085,
        "max_connections": 50
    },
    "storage": {
        "shared_directory": "./shared_files3",
        "max_file_size": "100MB",
        "allowed_extensions": [".pdf", ".txt", ".jpg", ".png", ".docx", ".zip"]
    },
    "peers": {
        "bootstrap_peers": [
            "http://127.0.0.1:8080",
            "http://127.0.0.1:8082"
        ],
        "backup_peers": [
            "http://127.0.0.1:8080"
        ]
    },
    "security": {
        "enable_auth": false,
        "api_key": null
    },
    "logging": {
        "level": "INFO",
        "file": "logs/peer3.log"
    }
}
EOF

# Crear directorios para peers adicionales
mkdir -p shared_files2 shared_files3

# Agregar archivos de ejemplo a cada peer
echo "Archivo específico del peer 2" > shared_files2/peer2_file.txt
echo "Datos únicos del segundo peer" > shared_files2/unique_data.txt

echo "Archivo específico del peer 3" > shared_files3/peer3_file.txt
echo "Información del tercer peer" > shared_files3/info.txt

echo "=== Configuración completada ==="
echo ""
echo "Para iniciar el sistema:"
echo "1. Peer principal: python src/p2p_node.py"
echo "2. Peer 2: python src/p2p_node.py --config src/config/peer2_config.json"
echo "3. Peer 3: python src/p2p_node.py --config src/config/peer3_config.json"
echo ""
echo "O crear red de prueba automática:"
echo "python src/p2p_node.py --test-network 3"