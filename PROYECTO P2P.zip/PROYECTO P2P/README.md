# Proyecto P2P - Comunicación entre procesos mediante API REST y RPC

## Resumen del Proyecto
Sistema P2P donde cada nodo/proceso contiene microservicios que soportan un sistema de compartición de archivos distribuido y descentralizado.

## Objetivos
- Implementar sistema P2P sin servidor de directorio centralizado
- Cada peer contiene módulos servidor (PServidor) y cliente (PCliente)
- Soporte de concurrencia para comunicación simultánea entre procesos remotos
- Implementar servicios REST y RPC
- Sistema de transferencia y localización de archivos distribuido

## Arquitectura del Sistema

### Componentes Principales

#### 1. PServidor (Módulos Servidor)
- **Consulta de Archivos**: API para buscar archivos en el directorio local
- **Transferencia de Archivos**: Servicios ECO/DUMMY para descarga y carga
- **Concurrencia**: Soporte para múltiples procesos remotos simultáneos
- **APIs**: REST y RPC para comunicación entre peers

#### 2. PCliente (Módulo Cliente)
- **Conexión con Peers**: Comunicación con otros nodos de la red
- **Búsqueda de Recursos**: Localización de archivos distribuidos
- **Gestión de Transferencias**: Descarga y carga de archivos

#### 3. Sistema de Localización (Bootstrap)
- **Descubrimiento de Peers**: Mantiene lista de peers activos
- **Directorio Distribuido**: Índice de recursos sin centralización
- **Configuración Dinámica**: Lectura de configuración al inicio

### Protocolos de Comunicación

#### REST API
- `GET /files` - Listar archivos disponibles
- `GET /files/{filename}` - Descargar archivo específico
- `POST /files` - Subir archivo
- `GET /peers` - Obtener lista de peers conocidos
- `POST /register` - Registrar nuevo peer en la red

#### RPC (Remote Procedure Call)
- `searchFile(filename)` - Buscar archivo en la red
- `downloadFile(filename, peer_id)` - Descargar archivo de peer específico
- `uploadFile(filename, data)` - Subir archivo a la red
- `getPeers()` - Obtener peers activos
- `heartbeat()` - Verificar estado del peer

### Configuración Bootstrap
Cada peer tendrá un archivo de configuración con:
```json
{
  "listen_ip": "0.0.0.0",
  "listen_port": 8080,
  "rpc_port": 8081,
  "shared_directory": "./shared_files",
  "peer_friends": [
    "http://peer1.example.com:8080",
    "http://peer2.example.com:8080"
  ],
  "peer_substitutes": [
    "http://backup1.example.com:8080"
  ]
}
```

## Estructura de Directorios
```
PROYECTO_P2P/
├── docs/                    # Documentación técnica
├── src/
│   ├── pservidor/          # Módulos servidor
│   │   ├── rest_api/       # API REST
│   │   ├── rpc_server/     # Servidor RPC
│   │   └── file_manager/   # Gestión de archivos
│   ├── pcliente/           # Módulo cliente
│   ├── common/             # Utilidades compartidas
│   └── config/             # Configuraciones
├── tests/                  # Pruebas del sistema
├── docker/                 # Configuración Docker
├── shared_files/           # Directorio de archivos compartidos
└── requirements.txt        # Dependencias Python
```

## Tecnologías Utilizadas
- **Lenguaje**: Python 3.8+
- **Framework Web**: Flask/FastAPI para REST
- **RPC**: grpcio o xmlrpc
- **Concurrencia**: asyncio/threading
- **Contenedores**: Docker
- **Despliegue**: AWS/Local

## Plan de Desarrollo
1. Análisis y diseño del sistema ✅
2. Estructura del proyecto
3. Implementación PServidor
4. Implementación PCliente
5. Sistema de localización
6. Integración REST/RPC
7. Gestión de archivos
8. Configuración entorno
9. Pruebas
10. Documentación técnica