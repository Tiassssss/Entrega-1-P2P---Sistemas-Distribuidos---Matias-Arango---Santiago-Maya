"""
Sistema P2P según diagrama de arquitectura
Implementa: PEER MAESTRO + PEER 1,2,3 con Pcliente + Pservidor + REST + gRPC
"""
import asyncio
import sys
from pathlib import Path

# Agregar el directorio raíz al path para importaciones
sys.path.append(str(Path(__file__).parent.parent.parent))

from src.pservidor.pservidor import Pservidor
from src.pcliente.pcliente import Pcliente
from src.peer_maestro import PeerMaestro
from src.common.models import PeerInfo, PeerStatus
from src.common.utils import setup_logging, get_local_ip, generate_peer_id
from src.config.config_manager import config_manager


class P2PNode:
    """
    Nodo P2P estándar (PEER 1, 2, 3 según diagrama)
    Implementa: -Pcliente + -Pservidor + REST + gRPC
    """
    
    def __init__(self, config_path: str = None):
        # Cargar configuración
        if config_path:
            config_manager.config_path = config_path
        
        self.config = config_manager.get_config()
        self.logger = setup_logging(
            log_level=self.config.logging.level,
            log_file=self.config.logging.file
        )
        
        # Componentes principales según diagrama
        self.pservidor = Pservidor()  # -Pservidor con REST + gRPC
        self.pcliente = Pcliente()    # -Pcliente
        
        # Estado del nodo
        self.running = False
        self.tasks = []
        
        # Información del nodo local
        self.local_peer_info = PeerInfo(
            peer_id=self.config.peer_id,
            address=get_local_ip(),
            port=self.config.network.listen_port,
            rpc_port=self.config.network.rpc_port,
            status=PeerStatus.ACTIVE,
            files_count=0,
            last_seen=None
        )
    
    async def start(self) -> None:
        """Inicia el nodo P2P completo"""
        if self.running:
            self.logger.warning("Node is already running")
            return
        
        self.logger.info(f"Starting P2P Node {self.config.peer_id}")
        self.logger.info("Componentes: -Pcliente + -Pservidor + REST + gRPC")
        self.running = True
        
        try:
            # Inicializar componentes
            await self.pservidor.initialize()
            await self.pcliente.initialize()
            
            # Iniciar servidor en background
            server_task = asyncio.create_task(self.pservidor.start())
            
            # Iniciar tareas de mantenimiento
            maintenance_task = asyncio.create_task(self._maintenance_loop())
            heartbeat_task = asyncio.create_task(self._heartbeat_loop())
            
            self.tasks = [server_task, maintenance_task, heartbeat_task]
            
            self.logger.info(f"P2P Node started successfully")
            self.logger.info(f"Node ID: {self.config.peer_id}")
            self.logger.info(f"Local IP: {self.local_peer_info.address}")
            self.logger.info(f"REST API: http://{self.local_peer_info.address}:{self.local_peer_info.port}")
            self.logger.info(f"RPC Server: {self.local_peer_info.address}:{self.local_peer_info.rpc_port}")
            
            # Registrarse con peers bootstrap usando -Pcliente
            await self._register_with_bootstrap_peers()
            
            # Esperar por las tareas principales
            await asyncio.gather(*self.tasks, return_exceptions=True)
            
        except Exception as e:
            self.logger.error(f"Error starting node: {e}")
            await self.stop()
            raise
    
    async def stop(self) -> None:
        """Detiene el nodo P2P"""
        if not self.running:
            return
        
        self.logger.info("Stopping P2P Node...")
        self.running = False
        
        # Cancelar tareas
        for task in self.tasks:
            if not task.done():
                task.cancel()
        
        # Esperar que terminen
        if self.tasks:
            await asyncio.gather(*self.tasks, return_exceptions=True)
        
        # Detener servidor
        await self.pservidor.stop()
        
        self.logger.info("P2P Node stopped")
    
    async def _register_with_bootstrap_peers(self) -> None:
        """Se registra con los peers bootstrap configurados usando -Pcliente"""
        bootstrap_peers = self.pcliente.network_discovery.get_active_peers()
        
        if not bootstrap_peers:
            self.logger.warning("No bootstrap peers available for registration")
            return
        
        self.logger.info(f"Registering with {len(bootstrap_peers)} bootstrap peers")
        
        registration_tasks = []
        for peer in bootstrap_peers:
            task = self._register_with_peer(peer)
            registration_tasks.append(task)
        
        # Registrarse en paralelo
        results = await asyncio.gather(*registration_tasks, return_exceptions=True)
        
        successful_registrations = sum(1 for r in results if r is True)
        self.logger.info(f"Successfully registered with {successful_registrations}/{len(bootstrap_peers)} peers")
    
    async def _register_with_peer(self, peer: PeerInfo) -> bool:
        """Se registra con un peer específico"""
        try:
            # Actualizar información local
            self.local_peer_info.files_count = len(self.pservidor.file_manager.get_files())
            
            # Intentar registro REST primero
            success = await self.pcliente.rest_client.register_with_peer(peer, self.local_peer_info)
            
            if success:
                self.logger.debug(f"Registered with peer {peer.peer_id} via REST")
                return True
            
            # Si REST falla, intentar RPC
            success = await self.pcliente.rpc_client.register_with_peer(peer, self.local_peer_info)
            
            if success:
                self.logger.debug(f"Registered with peer {peer.peer_id} via RPC")
                return True
            
            self.logger.warning(f"Failed to register with peer {peer.peer_id}")
            return False
            
        except Exception as e:
            self.logger.error(f"Error registering with peer {peer.peer_id}: {e}")
            return False
    
    async def _maintenance_loop(self) -> None:
        """Loop de mantenimiento del nodo"""
        while self.running:
            try:
                # Actualizar estado de la red cada 2 minutos
                await self.pcliente.refresh_network()
                
                # Limpiar peers inactivos
                self.pservidor.peer_registry.cleanup_inactive_peers(timeout_minutes=10)
                
                # Re-escanear archivos locales
                await self.pservidor.file_manager.scan_files()
                
                # Esperar 2 minutos
                await asyncio.sleep(120)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Error in maintenance loop: {e}")
                await asyncio.sleep(60)
    
    async def _heartbeat_loop(self) -> None:
        """Loop de heartbeat para mantener conectividad"""
        while self.running:
            try:
                # Enviar heartbeat a peers activos cada 30 segundos
                active_peers = self.pcliente.network_discovery.get_active_peers()
                
                # Actualizar información local
                self.local_peer_info.files_count = len(self.pservidor.file_manager.get_files())
                
                heartbeat_tasks = []
                for peer in active_peers:
                    task = self._send_heartbeat_to_peer(peer)
                    heartbeat_tasks.append(task)
                
                if heartbeat_tasks:
                    await asyncio.gather(*heartbeat_tasks, return_exceptions=True)
                
                await asyncio.sleep(30)  # Heartbeat cada 30 segundos
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Error in heartbeat loop: {e}")
                await asyncio.sleep(30)
    
    async def _send_heartbeat_to_peer(self, peer: PeerInfo) -> bool:
        """Envía heartbeat a un peer específico"""
        try:
            success = await self.pcliente.rpc_client.send_heartbeat_to_peer(
                peer,
                self.local_peer_info.peer_id,
                self.local_peer_info.status.value,
                self.local_peer_info.files_count
            )
            
            if not success:
                # Si RPC falla, marcar peer como posiblemente inactivo
                self.pcliente.network_discovery.known_peers[peer.peer_id].status = PeerStatus.UNKNOWN
            
            return success
            
        except Exception as e:
            self.logger.debug(f"Heartbeat failed to peer {peer.peer_id}: {e}")
            return False
    
    def get_node_status(self) -> dict:
        """Obtiene el estado completo del nodo"""
        pservidor_status = self.pservidor.get_status() if self.pservidor else {}
        
        return {
            "node_id": self.config.peer_id,
            "running": self.running,
            "local_address": f"{self.local_peer_info.address}:{self.local_peer_info.port}",
            "components": ["-Pcliente", "-Pservidor"],
            "protocols": ["REST", "gRPC"], 
            "pservidor_status": pservidor_status,
            "network_peers": len(self.pcliente.network_discovery.known_peers) if self.pcliente else 0,
            "active_peers": len(self.pcliente.network_discovery.get_active_peers()) if self.pcliente else 0
        }
    
    # Métodos de conveniencia para operaciones según diagrama
    async def consulta_peers(self, query: str, use_rpc: bool = False):
        """Consulta Peers - Delegado al Pcliente"""
        return await self.pcliente.consulta_peers(query)
    
    async def solicita_download(self, filename: str, use_rpc: bool = False):
        """Solicita Download - Delegado al Pcliente"""
        return await self.pcliente.solicita_download(filename, use_rpc)
    
    async def solicita_upload(self, filename: str, data: bytes, use_rpc: bool = False):
        """Solicita Upload - Delegado al Pcliente"""
        return await self.pcliente.solicita_upload(filename, data, use_rpc)
    
    # Métodos de compatibilidad (mantener interfaz existente)
    async def search_files(self, query: str, use_rpc: bool = False):
        """Busca archivos en la red (método de compatibilidad)"""
        return await self.pcliente.search_files(query, use_rpc)
    
    async def download_file(self, filename: str, use_rpc: bool = False):
        """Descarga un archivo de la red (método de compatibilidad)"""
        return await self.pcliente.download_file(filename, use_rpc)
    
    async def list_local_files(self):
        """Lista archivos locales"""
        return self.pservidor.file_manager.get_files()
    
    async def upload_local_file(self, filename: str, data: bytes):
        """Sube un archivo al directorio local"""
        return await self.pservidor.file_manager.write_file(filename, data)


class BootstrapManager:
    """Gestor de bootstrap para iniciar múltiples nodos"""
    
    def __init__(self):
        self.logger = setup_logging()
        self.nodes = {}
    
    async def create_test_network(self, num_nodes: int = 3) -> Dict[str, P2PNode]:
        """Crea una red de prueba con múltiples nodos"""
        self.logger.info(f"Creating test network with {num_nodes} nodes")
        
        # Crear configuraciones para cada nodo
        base_port = 8080
        nodes = {}
        
        for i in range(num_nodes):
            node_id = f"test_node_{i}"
            
            # Crear configuración temporal
            config = {
                "peer_id": node_id,
                "network": {
                    "listen_ip": "0.0.0.0",
                    "listen_port": base_port + (i * 2),
                    "rpc_port": base_port + (i * 2) + 1,
                    "max_connections": 50
                },
                "storage": {
                    "shared_directory": f"./test_shared_{i}",
                    "max_file_size": "100MB",
                    "allowed_extensions": [".txt", ".pdf", ".jpg", ".png"]
                },
                "peers": {
                    "bootstrap_peers": [],
                    "backup_peers": []
                },
                "security": {
                    "enable_auth": False,
                    "api_key": None
                },
                "logging": {
                    "level": "INFO",
                    "file": f"logs/test_node_{i}.log"
                }
            }
            
            # Si no es el primer nodo, agregar el primer nodo como bootstrap
            if i > 0:
                config["peers"]["bootstrap_peers"] = [f"http://127.0.0.1:{base_port}"]
            
            # Guardar configuración temporal
            config_path = f"/tmp/test_node_{i}_config.json"
            import json
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=2)
            
            # Crear nodo
            node = P2PNode(config_path)
            nodes[node_id] = node
        
        self.nodes.update(nodes)
        return nodes
    
    async def start_all_nodes(self, nodes: Dict[str, P2PNode]) -> None:
        """Inicia todos los nodos en paralelo"""
        self.logger.info("Starting all nodes...")
        
        start_tasks = []
        for node_id, node in nodes.items():
            task = asyncio.create_task(node.start())
            start_tasks.append(task)
        
        await asyncio.gather(*start_tasks, return_exceptions=True)
        self.logger.info("All nodes started")
    
    async def stop_all_nodes(self, nodes: Dict[str, P2PNode]) -> None:
        """Detiene todos los nodos"""
        self.logger.info("Stopping all nodes...")
        
        stop_tasks = []
        for node in nodes.values():
            task = asyncio.create_task(node.stop())
            stop_tasks.append(task)
        
        await asyncio.gather(*stop_tasks, return_exceptions=True)
        self.logger.info("All nodes stopped")


async def main():
    """Función principal para iniciar un nodo P2P según diagrama"""
    import argparse
    
    parser = argparse.ArgumentParser(description='P2P Node (PEER 1,2,3 según diagrama)')
    parser.add_argument('--config', type=str, help='Path to config file')
    parser.add_argument('--maestro', action='store_true', help='Start as PEER MAESTRO')
    parser.add_argument('--test-network', type=int, help='Create test network with N nodes')
    
    args = parser.parse_args()
    
    try:
        if args.maestro:
            # Iniciar como PEER MAESTRO (DIRECTORIO + LOCALIZACIÓN)
            print("🎯 Iniciando PEER MAESTRO (DIRECTORIO + LOCALIZACIÓN + Pcliente + Pservidor)")
            maestro = PeerMaestro(args.config)
            await maestro.start()
        elif args.test_network:
            # Crear red de prueba
            bootstrap_manager = BootstrapManager()
            nodes = await bootstrap_manager.create_test_network(args.test_network)
            await bootstrap_manager.start_all_nodes(nodes)
        else:
            # Iniciar un nodo estándar (PEER 1, 2, 3)
            print(f"📡 Iniciando PEER estándar (-Pcliente + -Pservidor + REST + gRPC)")
            node = P2PNode(args.config)
            await node.start()
            
    except KeyboardInterrupt:
        print("\nShutdown requested by user")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())