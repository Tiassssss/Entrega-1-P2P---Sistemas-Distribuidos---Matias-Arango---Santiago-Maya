"""
Implementación del PEER MAESTRO según diagrama
Combina DIRECTORIO y LOCALIZACIÓN con Pcliente y Pservidor
"""
import asyncio
import sys
from pathlib import Path

# Agregar el directorio raíz al path para importaciones
sys.path.append(str(Path(__file__).parent.parent.parent))

from src.pservidor.pservidor import Pservidor
from src.pcliente.pcliente import Pcliente
from src.common.models import PeerInfo, PeerStatus
from src.common.utils import setup_logging, get_local_ip, generate_peer_id
from src.config.config_manager import config_manager


class Localizacion:
    """
    Servicio de LOCALIZACIÓN del PEER MAESTRO según diagrama
    Permite ubicar peers y servicios en la red P2P
    """
    
    def __init__(self, pcliente: Pcliente, directorio):
        self.pcliente = pcliente
        self.directorio = directorio
        self.logger = setup_logging()
    
    async def localizar_peer(self, peer_id: str) -> PeerInfo:
        """Localiza un peer específico en la red"""
        self.logger.info(f"LOCALIZACIÓN: Buscando peer {peer_id}")
        
        # Primero buscar en directorio local
        peer = self.directorio.get_peer(peer_id)
        if peer and peer.status == PeerStatus.ACTIVE:
            return peer
        
        # Si no está local, consultar otros peers
        await self.pcliente.consulta_peers(f"peer:{peer_id}")
        
        # Volver a buscar después de consulta
        return self.directorio.get_peer(peer_id)
    
    async def localizar_archivo(self, filename: str) -> list:
        """Localiza dónde está disponible un archivo en la red"""
        self.logger.info(f"LOCALIZACIÓN: Buscando archivo {filename}")
        
        # Usar consulta de peers para buscar el archivo
        results = await self.pcliente.consulta_peers(filename)
        
        return results
    
    async def actualizar_ubicaciones(self) -> None:
        """Actualiza información de ubicaciones en la red"""
        self.logger.info("LOCALIZACIÓN: Actualizando ubicaciones de red")
        
        # Consultar maestro para obtener nueva información
        await self.pcliente.consulta_maestro()


class PeerMaestro:
    """
    PEER MAESTRO según diagrama
    Implementa: DIRECTORIO, LOCALIZACIÓN, -Pcliente, -Pservidor, REST + gRPC
    """
    
    def __init__(self, config_path: str = None):
        # Cargar configuración
        if config_path:
            config_manager.config_path = config_path
        
        self.config = config_manager.get_config()
        self.logger = setup_logging(
            log_level=self.config.logging.level,
            log_file=self.config.logging.file
        )
        
        # Componentes principales según diagrama
        self.pservidor = Pservidor()  # -Pservidor con REST + gRPC
        self.pcliente = Pcliente()    # -Pcliente 
        
        # Funciones específicas del PEER MAESTRO
        self.directorio = self.pservidor.directorio  # DIRECTORIO function
        self.localizacion = Localizacion(self.pcliente, self.directorio)  # LOCALIZACIÓN function
        
        # Estado del nodo
        self.running = False
        self.tasks = []
        
        # Información del peer maestro
        self.local_peer_info = PeerInfo(
            peer_id=self.config.peer_id,
            address=get_local_ip(),
            port=self.config.network.listen_port,
            rpc_port=self.config.network.rpc_port,
            status=PeerStatus.ACTIVE,
            files_count=0,
            last_seen=None
        )
    
    async def start(self) -> None:
        """Inicia el PEER MAESTRO completo"""
        if self.running:
            self.logger.warning("PeerMaestro is already running")
            return
        
        self.logger.info(f"Starting PEER MAESTRO {self.config.peer_id}")
        self.logger.info("Funciones: DIRECTORIO + LOCALIZACIÓN + Pcliente + Pservidor")
        self.running = True
        
        try:
            # Inicializar componentes
            await self.pservidor.initialize()
            await self.pcliente.initialize()
            
            # Iniciar servidor en background
            server_task = asyncio.create_task(self.pservidor.start())
            
            # Iniciar tareas específicas del PEER MAESTRO
            maestro_task = asyncio.create_task(self._maestro_loop())
            directorio_task = asyncio.create_task(self._directorio_loop())
            localizacion_task = asyncio.create_task(self._localizacion_loop())
            
            self.tasks = [server_task, maestro_task, directorio_task, localizacion_task]
            
            self.logger.info(f"PEER MAESTRO started successfully")
            self.logger.info(f"DIRECTORIO: Active at {self.local_peer_info.address}:{self.local_peer_info.port}")
            self.logger.info(f"LOCALIZACIÓN: Service running")
            self.logger.info(f"REST API: http://{self.local_peer_info.address}:{self.local_peer_info.port}")
            self.logger.info(f"gRPC Server: {self.local_peer_info.address}:{self.local_peer_info.rpc_port}")
            
            # Esperar por las tareas principales
            await asyncio.gather(*self.tasks, return_exceptions=True)
            
        except Exception as e:
            self.logger.error(f"Error starting PeerMaestro: {e}")
            await self.stop()
            raise
    
    async def stop(self) -> None:
        """Detiene el PEER MAESTRO"""
        if not self.running:
            return
        
        self.logger.info("Stopping PEER MAESTRO...")
        self.running = False
        
        # Cancelar tareas
        for task in self.tasks:
            if not task.done():
                task.cancel()
        
        # Esperar que terminen
        if self.tasks:
            await asyncio.gather(*self.tasks, return_exceptions=True)
        
        # Detener servidor
        await self.pservidor.stop()
        
        self.logger.info("PEER MAESTRO stopped")
    
    async def _maestro_loop(self) -> None:
        """Loop principal del PEER MAESTRO"""
        while self.running:
            try:
                # Actualizar información local
                self.local_peer_info.files_count = len(self.pservidor.file_manager.get_files())
                
                # Mantenimiento general cada 5 minutos
                await asyncio.sleep(300)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Error in maestro loop: {e}")
                await asyncio.sleep(60)
    
    async def _directorio_loop(self) -> None:
        """Loop de mantenimiento del DIRECTORIO"""
        while self.running:
            try:
                # Limpiar peers inactivos del directorio cada 10 minutos
                self.directorio.cleanup_inactive_peers(timeout_minutes=10)
                
                active_peers = len(self.directorio.get_active_peers())
                self.logger.info(f"DIRECTORIO: Managing {active_peers} active peers")
                
                await asyncio.sleep(600)  # 10 minutos
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Error in directorio loop: {e}")
                await asyncio.sleep(300)
    
    async def _localizacion_loop(self) -> None:
        """Loop de mantenimiento de LOCALIZACIÓN"""
        while self.running:
            try:
                # Actualizar ubicaciones cada 15 minutos
                await self.localizacion.actualizar_ubicaciones()
                
                self.logger.debug("LOCALIZACIÓN: Updated network locations")
                
                await asyncio.sleep(900)  # 15 minutos
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Error in localizacion loop: {e}")
                await asyncio.sleep(300)
    
    def get_maestro_status(self) -> dict:
        """Obtiene el estado completo del PEER MAESTRO"""
        pservidor_status = self.pservidor.get_status() if self.pservidor else {}
        
        return {
            "peer_maestro_id": self.config.peer_id,
            "running": self.running,
            "local_address": f"{self.local_peer_info.address}:{self.local_peer_info.port}",
            "functions": ["DIRECTORIO", "LOCALIZACIÓN", "Pcliente", "Pservidor"],
            "protocols": ["REST", "gRPC"],
            "directorio_peers": len(self.directorio.get_active_peers()),
            "local_files": len(self.pservidor.file_manager.get_files()),
            "pservidor_status": pservidor_status
        }
    
    # Métodos de interfaz según diagrama
    async def consulta_maestro(self) -> dict:
        """Interface para que otros peers consulten al maestro"""
        return {
            "directorio": [peer.to_dict() for peer in self.directorio.get_active_peers()],
            "localizacion_service": "active",
            "peer_maestro_id": self.config.peer_id
        }
    
    async def registrar_peer(self, peer_info: PeerInfo) -> bool:
        """Registra un nuevo peer en el DIRECTORIO"""
        try:
            self.directorio.register_peer(peer_info)
            self.logger.info(f"PEER MAESTRO: Registered peer {peer_info.peer_id}")
            return True
        except Exception as e:
            self.logger.error(f"Error registering peer: {e}")
            return False
    
    async def localizar_recurso(self, resource_name: str) -> list:
        """Localiza un recurso usando el servicio de LOCALIZACIÓN"""
        return await self.localizacion.localizar_archivo(resource_name)


async def main():
    """Función principal para iniciar el PEER MAESTRO"""
    import argparse
    
    parser = argparse.ArgumentParser(description='PEER MAESTRO P2P')
    parser.add_argument('--config', type=str, help='Path to config file')
    
    args = parser.parse_args()
    
    try:
        peer_maestro = PeerMaestro(args.config)
        await peer_maestro.start()
            
    except KeyboardInterrupt:
        print("\nShutdown requested by user")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())