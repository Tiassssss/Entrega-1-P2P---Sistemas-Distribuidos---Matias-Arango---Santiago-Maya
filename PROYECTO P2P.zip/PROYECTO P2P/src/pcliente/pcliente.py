"""
Módulo principal del Pcliente (según diagrama)
Coordina: -Consulta maestro, -Consulta Peers, -Solicita Upload, -Solicita Download
"""
import asyncio
from typing import List, Optional, Dict, Set
from datetime import datetime, timedelta

from .rest_client import RestClient
from .rpc_client import RPCClient
from ..common.models import FileInfo, PeerInfo, SearchResult, SearchQuery, PeerStatus
from ..common.utils import setup_logging
from ..config.config_manager import config_manager


class NetworkDiscovery:
    """Servicio de descubrimiento de la red P2P"""
    
    def __init__(self, rest_client: RestClient, rpc_client: RPCClient):
        self.rest_client = rest_client
        self.rpc_client = rpc_client
        self.logger = setup_logging()
        self.known_peers: Dict[str, PeerInfo] = {}
        self.discovery_in_progress = False
    
    async def bootstrap_network(self, bootstrap_peers: List[str]) -> None:
        """Inicia el descubrimiento de la red usando peers bootstrap"""
        self.logger.info("Starting network discovery...")
        
        # Convertir URLs bootstrap a PeerInfo
        initial_peers = []
        for i, peer_url in enumerate(bootstrap_peers):
            if peer_url.startswith('http://'):
                address_port = peer_url[7:]
                if ':' in address_port:
                    address, port_str = address_port.split(':')
                    port = int(port_str)
                else:
                    address = address_port
                    port = 8080
                
                peer_info = PeerInfo(
                    peer_id=f"bootstrap_{i}",
                    address=address,
                    port=port,
                    rpc_port=port + 1,
                    status=PeerStatus.UNKNOWN,
                    files_count=0,
                    last_seen=datetime.now()
                )
                initial_peers.append(peer_info)
        
        # Descubrir peers desde los iniciales
        for peer in initial_peers:
            await self._discover_peers_from(peer)
        
        self.logger.info(f"Network discovery completed. Found {len(self.known_peers)} peers")
    
    async def _discover_peers_from(self, peer_info: PeerInfo) -> None:
        """Descubre peers adicionales a partir de un peer conocido"""
        try:
            # Intentar obtener información del peer
            peer_data = await self.rest_client.get_peer_info(peer_info)
            
            if peer_data.get('success', True):  # Asumir éxito si no hay campo success
                # Actualizar información del peer
                peer_info.peer_id = peer_data.get('peer_id', peer_info.peer_id)
                peer_info.status = PeerStatus.ACTIVE
                peer_info.files_count = peer_data.get('files_count', 0)
                peer_info.last_seen = datetime.now()
                
                # Agregar a peers conocidos
                self.known_peers[peer_info.peer_id] = peer_info
                
                # Obtener lista de peers que conoce este peer
                discovered_peers = await self.rest_client.get_peers_from_peer(peer_info)
                
                for discovered_peer in discovered_peers:
                    if discovered_peer.peer_id not in self.known_peers:
                        self.known_peers[discovered_peer.peer_id] = discovered_peer
                        self.logger.debug(f"Discovered new peer: {discovered_peer.peer_id}")
            
        except Exception as e:
            self.logger.warning(f"Failed to discover peers from {peer_info.peer_id}: {e}")
            peer_info.status = PeerStatus.INACTIVE
    
    def get_active_peers(self) -> List[PeerInfo]:
        """Retorna lista de peers activos"""
        return [peer for peer in self.known_peers.values() 
                if peer.status == PeerStatus.ACTIVE]
    
    async def update_peer_status(self) -> None:
        """Actualiza el estado de todos los peers conocidos"""
        for peer_id, peer_info in self.known_peers.items():
            try:
                # Intentar obtener información básica
                peer_data = await self.rest_client.get_peer_info(peer_info)
                peer_info.status = PeerStatus.ACTIVE
                peer_info.last_seen = datetime.now()
                peer_info.files_count = peer_data.get('files_count', peer_info.files_count)
                
            except Exception:
                # Marcar como inactivo si no responde
                peer_info.status = PeerStatus.INACTIVE


class DistributedSearch:
    """Servicio de búsqueda distribuida en la red P2P"""
    
    def __init__(self, network_discovery: NetworkDiscovery, rest_client: RestClient, rpc_client: RPCClient):
        self.network_discovery = network_discovery
        self.rest_client = rest_client
        self.rpc_client = rpc_client
        self.logger = setup_logging()
        self.search_cache: Dict[str, List[SearchResult]] = {}
        self.cache_timeout = timedelta(minutes=5)
    
    async def search_network(self, query: str, use_rpc: bool = False) -> List[SearchResult]:
        """Busca archivos en toda la red P2P"""
        self.logger.info(f"Searching network for: '{query}'")
        
        # Verificar cache
        cache_key = f"{query}_{use_rpc}"
        if cache_key in self.search_cache:
            # TODO: Verificar si el cache ha expirado
            self.logger.debug("Returning cached search results")
            return self.search_cache[cache_key]
        
        results = []
        active_peers = self.network_discovery.get_active_peers()
        
        if not active_peers:
            self.logger.warning("No active peers found for search")
            return results
        
        # Buscar en paralelo en todos los peers activos
        search_tasks = []
        for peer in active_peers:
            if use_rpc:
                task = self._search_peer_rpc(peer, query)
            else:
                task = self._search_peer_rest(peer, query)
            search_tasks.append(task)
        
        # Ejecutar búsquedas en paralelo
        peer_results = await asyncio.gather(*search_tasks, return_exceptions=True)
        
        # Procesar resultados
        for peer, peer_files in zip(active_peers, peer_results):
            if isinstance(peer_files, Exception):
                self.logger.warning(f"Search failed on peer {peer.peer_id}: {peer_files}")
                continue
            
            for file_info in peer_files:
                search_result = SearchResult(
                    file_info=file_info,
                    peer_info=peer,
                    relevance_score=self._calculate_relevance(query, file_info.filename)
                )
                results.append(search_result)
        
        # Ordenar por relevancia
        results.sort(key=lambda x: x.relevance_score, reverse=True)
        
        # Guardar en cache
        self.search_cache[cache_key] = results
        
        self.logger.info(f"Search completed. Found {len(results)} results from {len(active_peers)} peers")
        return results
    
    async def _search_peer_rest(self, peer: PeerInfo, query: str) -> List[FileInfo]:
        """Busca archivos en un peer usando REST"""
        try:
            return await self.rest_client.search_files_on_peer(peer, query)
        except Exception as e:
            self.logger.debug(f"REST search failed on peer {peer.peer_id}: {e}")
            return []
    
    async def _search_peer_rpc(self, peer: PeerInfo, query: str) -> List[FileInfo]:
        """Busca archivos en un peer usando RPC"""
        try:
            config = config_manager.get_config()
            return await self.rpc_client.search_file_on_peer(peer, query, config.peer_id)
        except Exception as e:
            self.logger.debug(f"RPC search failed on peer {peer.peer_id}: {e}")
            return []
    
    def _calculate_relevance(self, query: str, filename: str) -> float:
        """Calcula la relevancia de un archivo para una búsqueda"""
        query_lower = query.lower()
        filename_lower = filename.lower()
        
        # Coincidencia exacta
        if query_lower == filename_lower:
            return 1.0
        
        # Contiene la query completa
        if query_lower in filename_lower:
            return 0.8
        
        # Coincidencia de palabras
        query_words = query_lower.split()
        filename_words = filename_lower.split()
        
        matches = sum(1 for word in query_words if word in filename_lower)
        if matches > 0:
            return 0.5 + (matches / len(query_words)) * 0.3
        
        return 0.1  # Relevancia mínima


class FileDownloader:
    """Servicio de descarga de archivos"""
    
    def __init__(self, rest_client: RestClient, rpc_client: RPCClient):
        self.rest_client = rest_client
        self.rpc_client = rpc_client
        self.logger = setup_logging()
        self.download_progress: Dict[str, float] = {}
    
    async def download_file(self, search_result: SearchResult, use_rpc: bool = False) -> bytes:
        """Descarga un archivo de un peer específico"""
        peer = search_result.peer_info
        file_info = search_result.file_info
        
        self.logger.info(f"Downloading {file_info.filename} from {peer.peer_id}")
        
        try:
            if use_rpc:
                data = await self.rpc_client.download_file_from_peer(
                    peer, file_info.filename
                )
            else:
                data = await self.rest_client.download_file_from_peer(
                    peer, file_info.filename
                )
            
            # Verificar integridad si hay hash disponible
            if file_info.hash:
                # TODO: Verificar hash del archivo descargado
                pass
            
            self.logger.info(f"Successfully downloaded {file_info.filename} ({len(data)} bytes)")
            return data
            
        except Exception as e:
            self.logger.error(f"Failed to download {file_info.filename} from {peer.peer_id}: {e}")
            raise
    
    async def download_with_fallback(self, filename: str, search_results: List[SearchResult]) -> Optional[bytes]:
        """Intenta descargar un archivo con fallback a múltiples peers"""
        if not search_results:
            self.logger.warning(f"No peers available for downloading {filename}")
            return None
        
        # Ordenar por relevancia y estado del peer
        sorted_results = sorted(
            search_results,
            key=lambda x: (x.peer_info.status == PeerStatus.ACTIVE, x.relevance_score),
            reverse=True
        )
        
        last_error = None
        
        for result in sorted_results:
            try:
                self.logger.info(f"Attempting download from {result.peer_info.peer_id}")
                data = await self.download_file(result)
                return data
                
            except Exception as e:
                last_error = e
                self.logger.warning(f"Download failed from {result.peer_info.peer_id}: {e}")
                continue
        
        self.logger.error(f"All download attempts failed for {filename}. Last error: {last_error}")
        return None


class Pcliente:
    """
    Cliente P2P según diagrama
    Implementa: -Consulta maestro, -Consulta Peers, -Solicita Upload, -Solicita Download
    """
    
    def __init__(self):
        self.config = config_manager.get_config()
        self.logger = setup_logging(
            log_level=self.config.logging.level,
            log_file=self.config.logging.file
        )
        
        # Componentes de comunicación
        self.rest_client = RestClient()
        self.rpc_client = RPCClient()
        
        # Servicios principales
        self.network_discovery = NetworkDiscovery(self.rest_client, self.rpc_client)
        self.distributed_search = DistributedSearch(
            self.network_discovery, self.rest_client, self.rpc_client
        )
        self.file_downloader = FileDownloader(self.rest_client, self.rpc_client)
        
        self.initialized = False
    
    async def initialize(self) -> None:
        """Inicializa el cliente P2P"""
        if self.initialized:
            return
        
        self.logger.info(f"Initializing Pcliente for peer {self.config.peer_id}")
        
        # Descubrir la red P2P
        await self.consulta_maestro()
        
        self.initialized = True
        self.logger.info("Pcliente initialized successfully")
    
    async def consulta_maestro(self) -> None:
        """Consulta maestro - Función específica del diagrama"""
        self.logger.info("Ejecutando -Consulta maestro")
        await self.network_discovery.bootstrap_network(
            self.config.peers.bootstrap_peers
        )
    
    async def consulta_peers(self, query: str) -> List[SearchResult]:
        """Consulta Peers - Función específica del diagrama"""
        self.logger.info(f"Ejecutando -Consulta Peers para: {query}")
        if not self.initialized:
            await self.initialize()
        
        return await self.distributed_search.search_network(query, use_rpc=False)
    
    async def solicita_upload(self, filename: str, data: bytes, use_rpc: bool = False) -> bool:
        """Solicita Upload - Función específica del diagrama"""
        self.logger.info(f"Ejecutando -Solicita Upload para: {filename}")
        if not self.initialized:
            await self.initialize()
        
        # Buscar un peer activo para subir
        active_peers = self.network_discovery.get_active_peers()
        if not active_peers:
            self.logger.error("No active peers found for upload")
            return False
        
        target_peer = active_peers[0]  # Usar el primer peer activo
        
        try:
            if use_rpc:
                success = await self.rpc_client.upload_file_to_peer(target_peer, filename, data)
            else:
                success = await self.rest_client.upload_file_to_peer(target_peer, filename, data)
            
            self.logger.info(f"Upload {'successful' if success else 'failed'} for {filename}")
            return success
        except Exception as e:
            self.logger.error(f"Error in solicita_upload: {e}")
            return False
    
    async def solicita_download(self, filename: str, use_rpc: bool = False) -> Optional[bytes]:
        """Solicita Download - Función específica del diagrama"""
        self.logger.info(f"Ejecutando -Solicita Download para: {filename}")
        if not self.initialized:
            await self.initialize()
        
        return await self.file_downloader.download_file(filename, use_rpc)
    
    # Métodos de compatibilidad (mantener funcionalidad existente)
    async def search_files(self, query: str, use_rpc: bool = False) -> List[SearchResult]:
        """Busca archivos en la red P2P (método de compatibilidad)"""
        return await self.consulta_peers(query)
    
    async def download_file(self, filename: str, use_rpc: bool = False) -> Optional[bytes]:
        """Descarga un archivo específico de la red (método de compatibilidad)"""
        return await self.solicita_download(filename, use_rpc)
        
        # Descargar con fallback
        return await self.file_downloader.download_with_fallback(filename, exact_matches)
    
    async def get_network_status(self) -> Dict[str, any]:
        """Obtiene el estado actual de la red"""
        if not self.initialized:
            await self.initialize()
        
        active_peers = self.network_discovery.get_active_peers()
        
        return {
            "total_peers": len(self.network_discovery.known_peers),
            "active_peers": len(active_peers),
            "peer_list": [peer.to_dict() for peer in active_peers]
        }
    
    async def refresh_network(self) -> None:
        """Actualiza el estado de la red"""
        if not self.initialized:
            await self.initialize()
        
        await self.network_discovery.update_peer_status()
        
        # Limpiar cache de búsqueda
        self.distributed_search.search_cache.clear()
        
        self.logger.info("Network refreshed")


async def main():
    """Función principal para testing del cliente"""
    client = PCliente()
    await client.initialize()
    
    # Buscar archivos
    results = await client.search_files("test")
    print(f"Found {len(results)} files")
    
    for result in results:
        print(f"- {result.file_info.filename} on {result.peer_info.peer_id}")
    
    # Descargar un archivo si se encontró
    if results:
        filename = results[0].file_info.filename
        data = await client.download_file(filename)
        if data:
            print(f"Downloaded {filename}: {len(data)} bytes")


if __name__ == "__main__":
    asyncio.run(main())