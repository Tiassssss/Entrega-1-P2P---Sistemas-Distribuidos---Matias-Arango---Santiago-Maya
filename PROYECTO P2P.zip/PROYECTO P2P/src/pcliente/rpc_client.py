"""
Cliente RPC para comunicación con otros peers
"""
import grpc
import asyncio
from typing import List, Optional, AsyncIterator
from datetime import datetime

# Importaciones de protobuf (se generarán después)
# import p2p_pb2
# import p2p_pb2_grpc

from ..common.models import FileInfo, PeerInfo, SearchResult
from ..common.utils import setup_logging


class RPCClient:
    """Cliente RPC para comunicarse con otros peers"""
    
    def __init__(self):
        self.logger = setup_logging()
        self.chunk_size = 64 * 1024  # 64KB chunks
    
    async def connect_to_peer(self, peer_info: PeerInfo) -> grpc.aio.Channel:
        """Establece conexión con un peer"""
        address = f"{peer_info.address}:{peer_info.rpc_port}"
        
        try:
            channel = grpc.aio.insecure_channel(address)
            
            # Verificar conectividad
            await channel.channel_ready()
            
            self.logger.debug(f"Connected to peer {peer_info.peer_id} at {address}")
            return channel
            
        except Exception as e:
            self.logger.error(f"Failed to connect to peer {peer_info.peer_id}: {e}")
            raise
    
    async def search_file_on_peer(self, peer_info: PeerInfo, query: str, peer_id: str) -> List[FileInfo]:
        """Busca archivos en un peer específico"""
        try:
            channel = await self.connect_to_peer(peer_info)
            stub = p2p_pb2_grpc.P2PServiceStub(channel)
            
            request = p2p_pb2.SearchRequest(
                query=query,
                peer_id=peer_id,
                ttl=3,
                timestamp=int(datetime.now().timestamp())
            )
            
            response = await stub.SearchFile(request)
            
            if response.success:
                files = []
                for pb_file in response.files:
                    file_info = FileInfo(
                        filename=pb_file.filename,
                        size=pb_file.size,
                        hash=pb_file.hash,
                        peer_id=pb_file.peer_id,
                        last_modified=datetime.fromtimestamp(pb_file.last_modified),
                        status=pb_file.status
                    )
                    files.append(file_info)
                
                return files
            else:
                self.logger.warning(f"Search failed on peer {peer_info.peer_id}: {response.message}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error searching on peer {peer_info.peer_id}: {e}")
            return []
        finally:
            if 'channel' in locals():
                await channel.close()
    
    async def download_file_from_peer(self, peer_info: PeerInfo, filename: str, 
                                     offset: int = 0, size: Optional[int] = None) -> bytes:
        """Descarga un archivo de un peer específico"""
        try:
            channel = await self.connect_to_peer(peer_info)
            stub = p2p_pb2_grpc.P2PServiceStub(channel)
            
            request = p2p_pb2.DownloadRequest(
                filename=filename,
                offset=offset,
                size=size or 0
            )
            
            file_data = bytearray()
            
            async for chunk in stub.DownloadFile(request):
                file_data.extend(chunk.data)
                
                if chunk.is_last:
                    # Verificar hash si está disponible
                    if chunk.hash:
                        # TODO: Verificar integridad del archivo
                        pass
                    break
            
            self.logger.info(f"Downloaded {filename} from {peer_info.peer_id} ({len(file_data)} bytes)")
            return bytes(file_data)
            
        except Exception as e:
            self.logger.error(f"Error downloading {filename} from peer {peer_info.peer_id}: {e}")
            raise
        finally:
            if 'channel' in locals():
                await channel.close()
    
    async def upload_file_to_peer(self, peer_info: PeerInfo, filename: str, data: bytes) -> bool:
        """Sube un archivo a un peer específico"""
        try:
            channel = await self.connect_to_peer(peer_info)
            stub = p2p_pb2_grpc.P2PServiceStub(channel)
            
            async def chunk_generator():
                offset = 0
                while offset < len(data):
                    chunk_size = min(self.chunk_size, len(data) - offset)
                    chunk_data = data[offset:offset + chunk_size]
                    
                    is_last = offset + chunk_size >= len(data)
                    
                    chunk = p2p_pb2.FileChunk(
                        filename=filename,
                        offset=offset,
                        data=chunk_data,
                        is_last=is_last
                    )
                    
                    yield chunk
                    offset += chunk_size
            
            response = await stub.UploadFile(chunk_generator())
            
            if response.success:
                self.logger.info(f"Uploaded {filename} to {peer_info.peer_id}")
                return True
            else:
                self.logger.warning(f"Upload failed to peer {peer_info.peer_id}: {response.message}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error uploading {filename} to peer {peer_info.peer_id}: {e}")
            return False
        finally:
            if 'channel' in locals():
                await channel.close()
    
    async def get_peers_from_peer(self, peer_info: PeerInfo) -> List[PeerInfo]:
        """Obtiene la lista de peers conocidos por otro peer"""
        try:
            channel = await self.connect_to_peer(peer_info)
            stub = p2p_pb2_grpc.P2PServiceStub(channel)
            
            request = p2p_pb2.Empty()
            response = await stub.GetPeers(request)
            
            peers = []
            for pb_peer in response.peers:
                peer = PeerInfo(
                    peer_id=pb_peer.peer_id,
                    address=pb_peer.address,
                    port=pb_peer.port,
                    rpc_port=pb_peer.rpc_port,
                    status=pb_peer.status,
                    files_count=pb_peer.files_count,
                    last_seen=datetime.fromtimestamp(pb_peer.last_seen)
                )
                peers.append(peer)
            
            return peers
            
        except Exception as e:
            self.logger.error(f"Error getting peers from {peer_info.peer_id}: {e}")
            return []
        finally:
            if 'channel' in locals():
                await channel.close()
    
    async def send_heartbeat_to_peer(self, peer_info: PeerInfo, my_peer_id: str, 
                                   my_status: str, my_files_count: int) -> bool:
        """Envía heartbeat a un peer"""
        try:
            channel = await self.connect_to_peer(peer_info)
            stub = p2p_pb2_grpc.P2PServiceStub(channel)
            
            request = p2p_pb2.HeartbeatRequest(
                peer_id=my_peer_id,
                timestamp=int(datetime.now().timestamp()),
                status=my_status,
                files_count=my_files_count
            )
            
            response = await stub.Heartbeat(request)
            
            return response.success
            
        except Exception as e:
            self.logger.error(f"Error sending heartbeat to {peer_info.peer_id}: {e}")
            return False
        finally:
            if 'channel' in locals():
                await channel.close()
    
    async def register_with_peer(self, peer_info: PeerInfo, my_peer_info: PeerInfo) -> bool:
        """Se registra con otro peer"""
        try:
            channel = await self.connect_to_peer(peer_info)
            stub = p2p_pb2_grpc.P2PServiceStub(channel)
            
            request = p2p_pb2.PeerInfo(
                peer_id=my_peer_info.peer_id,
                address=my_peer_info.address,
                port=my_peer_info.port,
                rpc_port=my_peer_info.rpc_port,
                status=my_peer_info.status.value,
                files_count=my_peer_info.files_count,
                last_seen=int(my_peer_info.last_seen.timestamp())
            )
            
            response = await stub.RegisterPeer(request)
            
            if response.success:
                self.logger.info(f"Registered with peer {peer_info.peer_id}")
                return True
            else:
                self.logger.warning(f"Registration failed with peer {peer_info.peer_id}: {response.message}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error registering with peer {peer_info.peer_id}: {e}")
            return False
        finally:
            if 'channel' in locals():
                await channel.close()
    
    async def echo_file_with_peer(self, peer_info: PeerInfo, filename: str, data: bytes) -> bytes:
        """Usa el servicio ECO de un peer"""
        try:
            channel = await self.connect_to_peer(peer_info)
            stub = p2p_pb2_grpc.P2PServiceStub(channel)
            
            async def chunk_generator():
                offset = 0
                while offset < len(data):
                    chunk_size = min(self.chunk_size, len(data) - offset)
                    chunk_data = data[offset:offset + chunk_size]
                    
                    is_last = offset + chunk_size >= len(data)
                    
                    chunk = p2p_pb2.FileChunk(
                        filename=filename,
                        offset=offset,
                        data=chunk_data,
                        is_last=is_last
                    )
                    
                    yield chunk
                    offset += chunk_size
            
            result_data = bytearray()
            
            async for chunk in stub.EchoFile(chunk_generator()):
                result_data.extend(chunk.data)
                if chunk.is_last:
                    break
            
            return bytes(result_data)
            
        except Exception as e:
            self.logger.error(f"Error in echo service with peer {peer_info.peer_id}: {e}")
            raise
        finally:
            if 'channel' in locals():
                await channel.close()
    
    async def generate_dummy_file_from_peer(self, peer_info: PeerInfo, filename: str, size: int) -> bytes:
        """Solicita archivo dummy de un peer"""
        try:
            channel = await self.connect_to_peer(peer_info)
            stub = p2p_pb2_grpc.P2PServiceStub(channel)
            
            request = p2p_pb2.DummyFileRequest(
                filename=filename,
                size=size
            )
            
            file_data = bytearray()
            
            async for chunk in stub.GenerateDummyFile(request):
                file_data.extend(chunk.data)
                if chunk.is_last:
                    break
            
            return bytes(file_data)
            
        except Exception as e:
            self.logger.error(f"Error generating dummy file from peer {peer_info.peer_id}: {e}")
            raise
        finally:
            if 'channel' in locals():
                await channel.close()