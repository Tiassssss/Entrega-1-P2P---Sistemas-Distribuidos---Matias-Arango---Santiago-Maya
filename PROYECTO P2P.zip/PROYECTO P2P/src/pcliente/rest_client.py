"""
Cliente REST para comunicación HTTP con otros peers
"""
import aiohttp
import asyncio
from typing import List, Optional, Dict, Any
from datetime import datetime

from ..common.models import FileInfo, PeerInfo, APIResponse
from ..common.utils import setup_logging


class RestClient:
    """Cliente REST para comunicarse con otros peers via HTTP"""
    
    def __init__(self, timeout: int = 30):
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self.logger = setup_logging()
    
    async def _make_request(self, method: str, url: str, **kwargs) -> Dict[Any, Any]:
        """Realiza una petición HTTP genérica"""
        try:
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.request(method, url, **kwargs) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        raise aiohttp.ClientError(f"HTTP {response.status}: {await response.text()}")
                        
        except asyncio.TimeoutError:
            self.logger.error(f"Timeout making {method} request to {url}")
            raise
        except Exception as e:
            self.logger.error(f"Error making {method} request to {url}: {e}")
            raise
    
    async def get_peer_info(self, peer_info: PeerInfo) -> Dict[str, Any]:
        """Obtiene información básica de un peer"""
        url = f"{peer_info.url}/"
        return await self._make_request("GET", url)
    
    async def list_files_on_peer(self, peer_info: PeerInfo, query: Optional[str] = None) -> List[FileInfo]:
        """Lista archivos disponibles en un peer"""
        try:
            url = f"{peer_info.url}/api/files"
            params = {"query": query} if query else {}
            
            response = await self._make_request("GET", url, params=params)
            
            if response.get("success"):
                files = []
                for file_data in response.get("data", []):
                    file_info = FileInfo(
                        filename=file_data["filename"],
                        size=file_data["size"],
                        hash=file_data["hash"],
                        peer_id=file_data["peer_id"],
                        last_modified=datetime.fromisoformat(file_data["last_modified"]),
                        status=file_data["status"]
                    )
                    files.append(file_info)
                
                return files
            else:
                self.logger.warning(f"Failed to list files on peer {peer_info.peer_id}: {response.get('message')}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error listing files on peer {peer_info.peer_id}: {e}")
            return []
    
    async def download_file_from_peer(self, peer_info: PeerInfo, filename: str) -> bytes:
        """Descarga un archivo específico de un peer"""
        try:
            url = f"{peer_info.url}/api/files/{filename}"
            
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.read()
                        self.logger.info(f"Downloaded {filename} from {peer_info.peer_id} ({len(data)} bytes)")
                        return data
                    elif response.status == 404:
                        raise FileNotFoundError(f"File {filename} not found on peer {peer_info.peer_id}")
                    else:
                        raise Exception(f"HTTP {response.status}: {await response.text()}")
                        
        except Exception as e:
            self.logger.error(f"Error downloading {filename} from peer {peer_info.peer_id}: {e}")
            raise
    
    async def upload_file_to_peer(self, peer_info: PeerInfo, filename: str, data: bytes) -> bool:
        """Sube un archivo a un peer"""
        try:
            url = f"{peer_info.url}/api/files"
            
            # Preparar multipart form data
            form_data = aiohttp.FormData()
            form_data.add_field('file', data, filename=filename, content_type='application/octet-stream')
            
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.post(url, data=form_data) as response:
                    if response.status == 200:
                        result = await response.json()
                        if result.get("success"):
                            self.logger.info(f"Uploaded {filename} to {peer_info.peer_id}")
                            return True
                        else:
                            self.logger.warning(f"Upload failed: {result.get('message')}")
                            return False
                    else:
                        self.logger.error(f"Upload failed with HTTP {response.status}")
                        return False
                        
        except Exception as e:
            self.logger.error(f"Error uploading {filename} to peer {peer_info.peer_id}: {e}")
            return False
    
    async def get_file_info_from_peer(self, peer_info: PeerInfo, filename: str) -> Optional[FileInfo]:
        """Obtiene información de un archivo específico"""
        try:
            url = f"{peer_info.url}/api/files/{filename}/info"
            response = await self._make_request("GET", url)
            
            if response.get("success"):
                file_data = response.get("data")
                if file_data:
                    return FileInfo(
                        filename=file_data["filename"],
                        size=file_data["size"],
                        hash=file_data["hash"],
                        peer_id=file_data["peer_id"],
                        last_modified=datetime.fromisoformat(file_data["last_modified"]),
                        status=file_data["status"]
                    )
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error getting file info for {filename} from peer {peer_info.peer_id}: {e}")
            return None
    
    async def search_files_on_peer(self, peer_info: PeerInfo, query: str) -> List[FileInfo]:
        """Busca archivos en un peer específico"""
        try:
            url = f"{peer_info.url}/api/search"
            params = {"q": query}
            
            response = await self._make_request("GET", url, params=params)
            
            if response.get("success"):
                files = []
                for file_data in response.get("data", []):
                    file_info = FileInfo(
                        filename=file_data["filename"],
                        size=file_data["size"],
                        hash=file_data["hash"],
                        peer_id=file_data["peer_id"],
                        last_modified=datetime.fromisoformat(file_data["last_modified"]),
                        status=file_data["status"]
                    )
                    files.append(file_info)
                
                return files
            else:
                self.logger.warning(f"Search failed on peer {peer_info.peer_id}: {response.get('message')}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error searching on peer {peer_info.peer_id}: {e}")
            return []
    
    async def get_peers_from_peer(self, peer_info: PeerInfo) -> List[PeerInfo]:
        """Obtiene la lista de peers conocidos por otro peer"""
        try:
            url = f"{peer_info.url}/api/peers"
            response = await self._make_request("GET", url)
            
            if response.get("success"):
                peers = []
                for peer_data in response.get("data", []):
                    peer = PeerInfo(
                        peer_id=peer_data["peer_id"],
                        address=peer_data["address"],
                        port=peer_data["port"],
                        rpc_port=peer_data["rpc_port"],
                        status=peer_data["status"],
                        files_count=peer_data["files_count"],
                        last_seen=datetime.fromisoformat(peer_data["last_seen"])
                    )
                    peers.append(peer)
                
                return peers
            else:
                return []
                
        except Exception as e:
            self.logger.error(f"Error getting peers from {peer_info.peer_id}: {e}")
            return []
    
    async def register_with_peer(self, peer_info: PeerInfo, my_peer_info: PeerInfo) -> bool:
        """Se registra con otro peer"""
        try:
            url = f"{peer_info.url}/api/peers/register"
            data = my_peer_info.to_dict()
            
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.post(url, json=data) as response:
                    if response.status == 200:
                        result = await response.json()
                        if result.get("success"):
                            self.logger.info(f"Registered with peer {peer_info.peer_id}")
                            return True
                        else:
                            self.logger.warning(f"Registration failed: {result.get('message')}")
                            return False
                    else:
                        self.logger.error(f"Registration failed with HTTP {response.status}")
                        return False
                        
        except Exception as e:
            self.logger.error(f"Error registering with peer {peer_info.peer_id}: {e}")
            return False
    
    async def echo_file_with_peer(self, peer_info: PeerInfo, filename: str, data: bytes) -> bytes:
        """Usa el servicio ECO de un peer"""
        try:
            url = f"{peer_info.url}/api/services/echo/{filename}"
            
            # Preparar multipart form data
            form_data = aiohttp.FormData()
            form_data.add_field('file', data, filename=filename, content_type='application/octet-stream')
            
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.post(url, data=form_data) as response:
                    if response.status == 200:
                        result_data = await response.read()
                        self.logger.info(f"Echo service completed for {filename}")
                        return result_data
                    else:
                        raise Exception(f"Echo service failed with HTTP {response.status}")
                        
        except Exception as e:
            self.logger.error(f"Error in echo service with peer {peer_info.peer_id}: {e}")
            raise
    
    async def generate_dummy_file_from_peer(self, peer_info: PeerInfo, filename: str, size: int) -> bytes:
        """Solicita archivo dummy de un peer"""
        try:
            url = f"{peer_info.url}/api/services/dummy/{filename}"
            params = {"size": size}
            
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.post(url, params=params) as response:
                    if response.status == 200:
                        result_data = await response.read()
                        self.logger.info(f"Generated dummy file {filename} ({size} bytes)")
                        return result_data
                    else:
                        raise Exception(f"Dummy service failed with HTTP {response.status}")
                        
        except Exception as e:
            self.logger.error(f"Error generating dummy file from peer {peer_info.peer_id}: {e}")
            raise
    
    async def rescan_files_on_peer(self, peer_info: PeerInfo) -> List[FileInfo]:
        """Solicita re-escaneo de archivos en un peer"""
        try:
            url = f"{peer_info.url}/api/rescan"
            response = await self._make_request("POST", url)
            
            if response.get("success"):
                files = []
                for file_data in response.get("data", []):
                    file_info = FileInfo(
                        filename=file_data["filename"],
                        size=file_data["size"],
                        hash=file_data["hash"],
                        peer_id=file_data["peer_id"],
                        last_modified=datetime.fromisoformat(file_data["last_modified"]),
                        status=file_data["status"]
                    )
                    files.append(file_info)
                
                return files
            else:
                return []
                
        except Exception as e:
            self.logger.error(f"Error requesting rescan from peer {peer_info.peer_id}: {e}")
            return []