"""
Utilidades comunes para el sistema P2P
"""
import hashlib
import os
import logging
import asyncio
from datetime import datetime
from typing import Optional, List
import socket


def calculate_file_hash(file_path: str) -> str:
    """Calcula el hash SHA-256 de un archivo"""
    sha256_hash = hashlib.sha256()
    
    try:
        with open(file_path, "rb") as f:
            # Leer archivo en chunks para manejar archivos grandes
            for chunk in iter(lambda: f.read(4096), b""):
                sha256_hash.update(chunk)
        return sha256_hash.hexdigest()
    except FileNotFoundError:
        raise FileNotFoundError(f"Archivo no encontrado: {file_path}")
    except Exception as e:
        raise Exception(f"Error calculando hash: {e}")


def get_file_size(file_path: str) -> int:
    """Retorna el tamaño de un archivo en bytes"""
    try:
        return os.path.getsize(file_path)
    except FileNotFoundError:
        raise FileNotFoundError(f"Archivo no encontrado: {file_path}")


def is_valid_filename(filename: str, allowed_extensions: List[str]) -> bool:
    """Valida si un nombre de archivo es permitido"""
    if not filename or '..' in filename or '/' in filename or '\\' in filename:
        return False
    
    # Verificar extensión
    _, ext = os.path.splitext(filename.lower())
    return ext in [e.lower() for e in allowed_extensions]


def sanitize_filename(filename: str) -> str:
    """Sanitiza un nombre de archivo removiendo caracteres peligrosos"""
    # Remover caracteres peligrosos
    dangerous_chars = ['/', '\\', '..', '<', '>', ':', '"', '|', '?', '*']
    sanitized = filename
    
    for char in dangerous_chars:
        sanitized = sanitized.replace(char, '_')
    
    # Limitar longitud
    if len(sanitized) > 255:
        name, ext = os.path.splitext(sanitized)
        max_name_length = 255 - len(ext)
        sanitized = name[:max_name_length] + ext
    
    return sanitized


def get_local_ip() -> str:
    """Obtiene la IP local del sistema"""
    try:
        # Conectar a un servidor externo para obtener la IP local
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        return local_ip
    except Exception:
        return "127.0.0.1"


def is_port_available(port: int, host: str = "localhost") -> bool:
    """Verifica si un puerto está disponible"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((host, port))
            return True
    except OSError:
        return False


def setup_logging(log_level: str = "INFO", log_file: Optional[str] = None) -> logging.Logger:
    """Configura el sistema de logging"""
    
    # Crear directorio de logs si no existe
    if log_file:
        log_dir = os.path.dirname(log_file)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir)
    
    # Configurar formato
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Configurar logger principal
    logger = logging.getLogger('p2p')
    logger.setLevel(getattr(logging, log_level.upper()))
    
    # Handler para consola
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # Handler para archivo si se especifica
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger


async def timeout_after(seconds: float, coroutine):
    """Ejecuta una corrutina con timeout"""
    try:
        return await asyncio.wait_for(coroutine, timeout=seconds)
    except asyncio.TimeoutError:
        raise TimeoutError(f"Operación expiró después de {seconds} segundos")


def parse_file_size(size_str: str) -> int:
    """Convierte string de tamaño (ej: '100MB') a bytes"""
    size_str = size_str.strip().upper()
    
    multipliers = {
        'B': 1,
        'KB': 1024,
        'MB': 1024 ** 2,
        'GB': 1024 ** 3,
        'TB': 1024 ** 4
    }
    
    for suffix, multiplier in multipliers.items():
        if size_str.endswith(suffix):
            try:
                number = float(size_str[:-len(suffix)])
                return int(number * multiplier)
            except ValueError:
                break
    
    # Si no se puede parsear, asumir que está en bytes
    try:
        return int(size_str)
    except ValueError:
        raise ValueError(f"No se puede parsear el tamaño: {size_str}")


def format_file_size(size_bytes: int) -> str:
    """Formatea un tamaño en bytes a string legible"""
    if size_bytes == 0:
        return "0 B"
    
    size_names = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    
    while size_bytes >= 1024 and i < len(size_names) - 1:
        size_bytes /= 1024.0
        i += 1
    
    return f"{size_bytes:.1f} {size_names[i]}"


def generate_peer_id() -> str:
    """Genera un ID único para un peer"""
    import uuid
    import time
    
    # Combinar timestamp y UUID para mayor unicidad
    timestamp = int(time.time())
    unique_id = str(uuid.uuid4())[:8]
    
    return f"peer_{timestamp}_{unique_id}"


class RateLimiter:
    """Limitador de tasa simple"""
    
    def __init__(self, max_requests: int, time_window: int):
        self.max_requests = max_requests
        self.time_window = time_window
        self.requests = {}
    
    def is_allowed(self, identifier: str) -> bool:
        """Verifica si una solicitud está permitida"""
        now = datetime.now()
        
        if identifier not in self.requests:
            self.requests[identifier] = []
        
        # Limpiar solicitudes antiguas
        cutoff = now.timestamp() - self.time_window
        self.requests[identifier] = [
            req_time for req_time in self.requests[identifier]
            if req_time > cutoff
        ]
        
        # Verificar límite
        if len(self.requests[identifier]) >= self.max_requests:
            return False
        
        # Agregar nueva solicitud
        self.requests[identifier].append(now.timestamp())
        return True