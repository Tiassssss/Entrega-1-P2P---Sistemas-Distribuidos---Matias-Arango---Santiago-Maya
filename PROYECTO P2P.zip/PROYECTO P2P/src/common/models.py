"""
Modelos de datos comunes para el sistema P2P
"""
from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional
from enum import Enum


class PeerStatus(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    UNKNOWN = "unknown"


class FileStatus(Enum):
    AVAILABLE = "available"
    DOWNLOADING = "downloading"
    UPLOADING = "uploading"
    ERROR = "error"


@dataclass
class FileInfo:
    """Información de archivo disponible en un peer"""
    filename: str
    size: int
    hash: str
    peer_id: str
    last_modified: datetime
    status: FileStatus = FileStatus.AVAILABLE
    
    def to_dict(self) -> dict:
        return {
            "filename": self.filename,
            "size": self.size,
            "hash": self.hash,
            "peer_id": self.peer_id,
            "last_modified": self.last_modified.isoformat(),
            "status": self.status.value
        }


@dataclass
class PeerInfo:
    """Información de un peer en la red"""
    peer_id: str
    address: str
    port: int
    rpc_port: int
    status: PeerStatus
    files_count: int
    last_seen: datetime
    
    def to_dict(self) -> dict:
        return {
            "peer_id": self.peer_id,
            "address": self.address,
            "port": self.port,
            "rpc_port": self.rpc_port,
            "status": self.status.value,
            "files_count": self.files_count,
            "last_seen": self.last_seen.isoformat()
        }
    
    @property
    def url(self) -> str:
        return f"http://{self.address}:{self.port}"


@dataclass
class ChunkInfo:
    """Información de un chunk de archivo"""
    chunk_id: str
    offset: int
    size: int
    hash: str


@dataclass
class FileMetadata:
    """Metadatos extendidos de archivo"""
    filename: str
    size: int
    hash: str
    created_at: datetime
    modified_at: datetime
    peer_id: str
    chunks: List[ChunkInfo]
    mime_type: Optional[str] = None


@dataclass
class SearchQuery:
    """Query de búsqueda en la red P2P"""
    query: str
    peer_id: str
    timestamp: datetime
    ttl: int = 3  # Time To Live para evitar loops infinitos
    
    def to_dict(self) -> dict:
        return {
            "query": self.query,
            "peer_id": self.peer_id,
            "timestamp": self.timestamp.isoformat(),
            "ttl": self.ttl
        }


@dataclass
class SearchResult:
    """Resultado de búsqueda"""
    file_info: FileInfo
    peer_info: PeerInfo
    relevance_score: float = 1.0


@dataclass
class TransferRequest:
    """Solicitud de transferencia de archivo"""
    filename: str
    peer_id: str
    chunk_start: int = 0
    chunk_size: Optional[int] = None


@dataclass
class HeartbeatMessage:
    """Mensaje de heartbeat entre peers"""
    peer_id: str
    timestamp: datetime
    status: PeerStatus
    files_count: int
    
    def to_dict(self) -> dict:
        return {
            "peer_id": self.peer_id,
            "timestamp": self.timestamp.isoformat(),
            "status": self.status.value,
            "files_count": self.files_count
        }


class APIResponse:
    """Respuesta estándar de API"""
    
    @staticmethod
    def success(data=None, message="OK"):
        return {
            "success": True,
            "message": message,
            "data": data
        }
    
    @staticmethod
    def error(message="Error", code=400, data=None):
        return {
            "success": False,
            "message": message,
            "code": code,
            "data": data
        }