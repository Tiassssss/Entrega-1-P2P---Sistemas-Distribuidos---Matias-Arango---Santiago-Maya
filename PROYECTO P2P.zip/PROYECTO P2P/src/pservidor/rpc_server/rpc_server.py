"""
Servidor RPC para el sistema P2P
Implementa los servicios definidos en p2p.proto
"""
import asyncio
import grpc
from grpc import aio
from datetime import datetime
from typing import AsyncIterator
import time

# Importaciones de los archivos generados por protobuf (se generarán después)
# import p2p_pb2
# import p2p_pb2_grpc

from ..file_manager.file_manager import FileManager, EchoService, DummyService
from ...common.models import FileInfo as CommonFileInfo, PeerInfo as CommonPeerInfo
from ...common.utils import setup_logging
from ...config.config_manager import config_manager


class P2PServicer:
    """Implementación del servicio P2P gRPC"""
    
    def __init__(self, file_manager: FileManager, peer_registry):
        self.file_manager = file_manager
        self.peer_registry = peer_registry
        self.echo_service = EchoService(file_manager)
        self.dummy_service = DummyService(file_manager)
        self.logger = setup_logging()
        
        # Tamaño de chunk para transferencias
        self.chunk_size = 64 * 1024  # 64KB chunks
    
    async def SearchFile(self, request, context):
        """Busca archivos que coincidan con la consulta"""
        try:
            self.logger.info(f"Search request: {request.query} from {request.peer_id}")
            
            # Buscar archivos localmente
            local_files = self.file_manager.search_files(request.query)
            
            # Convertir a formato protobuf
            pb_files = []
            for file_info in local_files:
                pb_file = self._convert_file_info_to_pb(file_info)
                pb_files.append(pb_file)
            
            # Crear respuesta
            response = SearchResponse(
                files=pb_files,
                peer_id=config_manager.get_config().peer_id,
                success=True,
                message=f"Found {len(pb_files)} files"
            )
            
            return response
            
        except Exception as e:
            self.logger.error(f"Error in SearchFile: {e}")
            return SearchResponse(
                files=[],
                peer_id=config_manager.get_config().peer_id,
                success=False,
                message=f"Search error: {str(e)}"
            )
    
    async def DownloadFile(self, request, context) -> AsyncIterator:
        """Descarga un archivo por chunks"""
        try:
            filename = request.filename
            offset = request.offset
            size = request.size if request.size > 0 else None
            
            self.logger.info(f"Download request: {filename} from offset {offset}")
            
            # Verificar que el archivo existe
            file_info = self.file_manager.get_file_info(filename)
            if not file_info:
                context.set_code(grpc.StatusCode.NOT_FOUND)
                context.set_details(f"File not found: {filename}")
                return
            
            # Leer archivo por chunks
            current_offset = offset
            remaining_size = size if size else (file_info.size - offset)
            
            while remaining_size > 0:
                chunk_size = min(self.chunk_size, remaining_size)
                
                try:
                    chunk_data = await self.file_manager.read_file_chunk(
                        filename, current_offset, chunk_size
                    )
                    
                    is_last = remaining_size <= chunk_size
                    
                    chunk = FileChunk(
                        filename=filename,
                        offset=current_offset,
                        data=chunk_data,
                        is_last=is_last,
                        hash=file_info.hash if is_last else ""
                    )
                    
                    yield chunk
                    
                    current_offset += chunk_size
                    remaining_size -= chunk_size
                    
                except Exception as e:
                    self.logger.error(f"Error reading chunk: {e}")
                    context.set_code(grpc.StatusCode.INTERNAL)
                    context.set_details(f"Error reading file: {str(e)}")
                    return
            
        except Exception as e:
            self.logger.error(f"Error in DownloadFile: {e}")
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(f"Download error: {str(e)}")
    
    async def UploadFile(self, request_iterator, context):
        """Sube un archivo recibiendo chunks"""
        try:
            filename = None
            file_data = bytearray()
            
            async for chunk in request_iterator:
                if filename is None:
                    filename = chunk.filename
                    self.logger.info(f"Upload request: {filename}")
                
                file_data.extend(chunk.data)
                
                if chunk.is_last:
                    break
            
            if filename is None:
                context.set_code(grpc.StatusCode.INVALID_ARGUMENT)
                context.set_details("No filename provided")
                return UploadResponse(success=False, message="No filename provided")
            
            # Guardar archivo
            file_info = await self.file_manager.write_file(filename, bytes(file_data))
            
            # Convertir a formato protobuf
            pb_file_info = self._convert_file_info_to_pb(file_info)
            
            return UploadResponse(
                success=True,
                message=f"File {filename} uploaded successfully",
                file_info=pb_file_info
            )
            
        except Exception as e:
            self.logger.error(f"Error in UploadFile: {e}")
            return UploadResponse(
                success=False,
                message=f"Upload error: {str(e)}"
            )
    
    async def GetPeers(self, request, context):
        """Retorna la lista de peers conocidos"""
        try:
            peers = self.peer_registry.get_active_peers()
            
            pb_peers = []
            for peer in peers:
                pb_peer = self._convert_peer_info_to_pb(peer)
                pb_peers.append(pb_peer)
            
            return PeerList(
                peers=pb_peers,
                total_count=len(pb_peers)
            )
            
        except Exception as e:
            self.logger.error(f"Error in GetPeers: {e}")
            return PeerList(peers=[], total_count=0)
    
    async def RegisterPeer(self, request, context):
        """Registra un nuevo peer en la red"""
        try:
            # Convertir de protobuf a modelo común
            peer_info = self._convert_pb_to_peer_info(request)
            
            # Registrar peer
            self.peer_registry.register_peer(peer_info)
            
            self.logger.info(f"Registered peer: {peer_info.peer_id}")
            
            return RegisterResponse(
                success=True,
                message=f"Peer {peer_info.peer_id} registered successfully"
            )
            
        except Exception as e:
            self.logger.error(f"Error in RegisterPeer: {e}")
            return RegisterResponse(
                success=False,
                message=f"Registration error: {str(e)}"
            )
    
    async def Heartbeat(self, request, context):
        """Procesa heartbeat de un peer"""
        try:
            peer_id = request.peer_id
            
            # Actualizar información del peer
            self.peer_registry.update_peer_heartbeat(
                peer_id,
                request.status,
                request.files_count
            )
            
            return HeartbeatResponse(
                success=True,
                server_timestamp=int(time.time()),
                message="Heartbeat received"
            )
            
        except Exception as e:
            self.logger.error(f"Error in Heartbeat: {e}")
            return HeartbeatResponse(
                success=False,
                server_timestamp=int(time.time()),
                message=f"Heartbeat error: {str(e)}"
            )
    
    async def EchoFile(self, request_iterator, context) -> AsyncIterator:
        """Servicio ECO - retorna los mismos chunks recibidos"""
        try:
            async for chunk in request_iterator:
                # Simplemente reenviar el mismo chunk
                yield chunk
                
        except Exception as e:
            self.logger.error(f"Error in EchoFile: {e}")
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(f"Echo error: {str(e)}")
    
    async def GenerateDummyFile(self, request, context) -> AsyncIterator:
        """Servicio DUMMY - genera archivo de prueba"""
        try:
            filename = request.filename
            size = request.size
            
            self.logger.info(f"Generating dummy file: {filename}, size: {size}")
            
            # Generar contenido dummy
            dummy_data = await self.dummy_service.generate_dummy_file(filename, size)
            
            # Enviar por chunks
            offset = 0
            remaining = len(dummy_data)
            
            while remaining > 0:
                chunk_size = min(self.chunk_size, remaining)
                chunk_data = dummy_data[offset:offset + chunk_size]
                
                is_last = remaining <= chunk_size
                
                chunk = FileChunk(
                    filename=f"dummy_{filename}",
                    offset=offset,
                    data=chunk_data,
                    is_last=is_last
                )
                
                yield chunk
                
                offset += chunk_size
                remaining -= chunk_size
                
        except Exception as e:
            self.logger.error(f"Error in GenerateDummyFile: {e}")
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(f"Dummy file error: {str(e)}")
    
    def _convert_file_info_to_pb(self, file_info: CommonFileInfo):
        """Convierte FileInfo común a formato protobuf"""
        return FileInfo(
            filename=file_info.filename,
            size=file_info.size,
            hash=file_info.hash,
            peer_id=file_info.peer_id,
            last_modified=int(file_info.last_modified.timestamp()),
            status=file_info.status.value
        )
    
    def _convert_peer_info_to_pb(self, peer_info: CommonPeerInfo):
        """Convierte PeerInfo común a formato protobuf"""
        return PeerInfo(
            peer_id=peer_info.peer_id,
            address=peer_info.address,
            port=peer_info.port,
            rpc_port=peer_info.rpc_port,
            status=peer_info.status.value,
            files_count=peer_info.files_count,
            last_seen=int(peer_info.last_seen.timestamp())
        )
    
    def _convert_pb_to_peer_info(self, pb_peer_info) -> CommonPeerInfo:
        """Convierte PeerInfo de protobuf a modelo común"""
        return CommonPeerInfo(
            peer_id=pb_peer_info.peer_id,
            address=pb_peer_info.address,
            port=pb_peer_info.port,
            rpc_port=pb_peer_info.rpc_port,
            status=pb_peer_info.status,
            files_count=pb_peer_info.files_count,
            last_seen=datetime.fromtimestamp(pb_peer_info.last_seen)
        )


class RPCServer:
    """Servidor RPC para el sistema P2P"""
    
    def __init__(self, file_manager: FileManager, peer_registry):
        self.file_manager = file_manager
        self.peer_registry = peer_registry
        self.servicer = P2PServicer(file_manager, peer_registry)
        self.server = None
        self.logger = setup_logging()
    
    async def start_server(self, host: str = "0.0.0.0", port: int = 8081):
        """Inicia el servidor RPC"""
        self.logger.info(f"Starting RPC server on {host}:{port}")
        
        self.server = aio.server()
        
        # Agregar el servicer al servidor
        # p2p_pb2_grpc.add_P2PServiceServicer_to_server(self.servicer, self.server)
        
        # Configurar dirección de escucha
        listen_addr = f"{host}:{port}"
        self.server.add_insecure_port(listen_addr)
        
        await self.server.start()
        self.logger.info(f"RPC server started on {listen_addr}")
        
        # Esperar por finalización
        await self.server.wait_for_termination()
    
    async def stop_server(self):
        """Detiene el servidor RPC"""
        if self.server:
            self.logger.info("Stopping RPC server")
            await self.server.stop(grace=5)
            self.logger.info("RPC server stopped")


# Script para generar archivos protobuf
def generate_protobuf_files():
    """Genera los archivos Python desde el archivo .proto"""
    import subprocess
    import os
    
    proto_file = "src/pservidor/rpc_server/p2p.proto"
    output_dir = "src/pservidor/rpc_server/"
    
    try:
        # Comando para generar archivos Python desde proto
        cmd = [
            "python", "-m", "grpc_tools.protoc",
            f"--proto_path={os.path.dirname(proto_file)}",
            f"--python_out={output_dir}",
            f"--grpc_python_out={output_dir}",
            proto_file
        ]
        
        subprocess.run(cmd, check=True)
        print("Archivos protobuf generados exitosamente")
        
    except subprocess.CalledProcessError as e:
        print(f"Error generando archivos protobuf: {e}")
    except FileNotFoundError:
        print("grpc_tools no está instalado. Instalar con: pip install grpcio-tools")


if __name__ == "__main__":
    # Generar archivos protobuf si se ejecuta directamente
    generate_protobuf_files()