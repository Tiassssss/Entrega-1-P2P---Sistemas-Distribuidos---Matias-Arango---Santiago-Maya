"""
Gestor de archivos para el sistema P2P
Maneja la consulta, indexación y transferencia de archivos
"""
import os
import asyncio
import aiofiles
from datetime import datetime
from typing import List, Optional, Dict
from pathlib import Path

from ..common.models import FileInfo, FileMetadata, FileStatus
from ..common.utils import calculate_file_hash, get_file_size, is_valid_filename, sanitize_filename
from ..config.config_manager import config_manager


class FileManager:
    """Gestor de archivos local para un peer"""
    
    def __init__(self, shared_directory: str, peer_id: str):
        self.shared_directory = Path(shared_directory)
        self.peer_id = peer_id
        self.file_index: Dict[str, FileInfo] = {}
        self._ensure_directory_exists()
    
    def _ensure_directory_exists(self) -> None:
        """Crea el directorio compartido si no existe"""
        self.shared_directory.mkdir(parents=True, exist_ok=True)
    
    async def scan_files(self) -> List[FileInfo]:
        """Escanea el directorio compartido y actualiza el índice"""
        config = config_manager.get_config()
        self.file_index.clear()
        
        for file_path in self.shared_directory.iterdir():
            if file_path.is_file():
                filename = file_path.name
                
                # Validar extensión permitida
                if not is_valid_filename(filename, config.storage.allowed_extensions):
                    continue
                
                try:
                    # Calcular información del archivo
                    size = get_file_size(str(file_path))
                    file_hash = calculate_file_hash(str(file_path))
                    modified_time = datetime.fromtimestamp(file_path.stat().st_mtime)
                    
                    file_info = FileInfo(
                        filename=filename,
                        size=size,
                        hash=file_hash,
                        peer_id=self.peer_id,
                        last_modified=modified_time,
                        status=FileStatus.AVAILABLE
                    )
                    
                    self.file_index[filename] = file_info
                    
                except Exception as e:
                    print(f"Error escaneando archivo {filename}: {e}")
                    continue
        
        return list(self.file_index.values())
    
    def get_files(self) -> List[FileInfo]:
        """Retorna la lista de archivos disponibles"""
        return list(self.file_index.values())
    
    def get_file_info(self, filename: str) -> Optional[FileInfo]:
        """Retorna información de un archivo específico"""
        return self.file_index.get(filename)
    
    def search_files(self, query: str) -> List[FileInfo]:
        """Busca archivos que coincidan con la consulta"""
        query = query.lower()
        results = []
        
        for file_info in self.file_index.values():
            if query in file_info.filename.lower():
                results.append(file_info)
        
        return results
    
    async def read_file(self, filename: str) -> bytes:
        """Lee un archivo completo"""
        if filename not in self.file_index:
            raise FileNotFoundError(f"Archivo no encontrado: {filename}")
        
        file_path = self.shared_directory / filename
        
        async with aiofiles.open(file_path, 'rb') as file:
            return await file.read()
    
    async def read_file_chunk(self, filename: str, start: int, size: int) -> bytes:
        """Lee un chunk específico de un archivo"""
        if filename not in self.file_index:
            raise FileNotFoundError(f"Archivo no encontrado: {filename}")
        
        file_path = self.shared_directory / filename
        
        async with aiofiles.open(file_path, 'rb') as file:
            await file.seek(start)
            return await file.read(size)
    
    async def write_file(self, filename: str, data: bytes) -> FileInfo:
        """Escribe un archivo al directorio compartido"""
        config = config_manager.get_config()
        
        # Sanitizar nombre del archivo
        safe_filename = sanitize_filename(filename)
        
        # Validar extensión
        if not is_valid_filename(safe_filename, config.storage.allowed_extensions):
            raise ValueError(f"Extensión de archivo no permitida: {safe_filename}")
        
        # Verificar tamaño máximo
        max_size = config.storage.max_file_size
        if len(data) > max_size:
            raise ValueError(f"Archivo demasiado grande. Máximo: {max_size} bytes")
        
        file_path = self.shared_directory / safe_filename
        
        # Escribir archivo
        async with aiofiles.open(file_path, 'wb') as file:
            await file.write(data)
        
        # Calcular información del archivo
        file_hash = calculate_file_hash(str(file_path))
        modified_time = datetime.now()
        
        file_info = FileInfo(
            filename=safe_filename,
            size=len(data),
            hash=file_hash,
            peer_id=self.peer_id,
            last_modified=modified_time,
            status=FileStatus.AVAILABLE
        )
        
        # Actualizar índice
        self.file_index[safe_filename] = file_info
        
        return file_info
    
    async def delete_file(self, filename: str) -> bool:
        """Elimina un archivo del directorio compartido"""
        if filename not in self.file_index:
            return False
        
        file_path = self.shared_directory / filename
        
        try:
            file_path.unlink()
            del self.file_index[filename]
            return True
        except FileNotFoundError:
            # El archivo ya no existe, remover del índice
            del self.file_index[filename]
            return True
        except Exception:
            return False
    
    def get_file_path(self, filename: str) -> Optional[Path]:
        """Retorna la ruta completa de un archivo"""
        if filename not in self.file_index:
            return None
        
        return self.shared_directory / filename
    
    async def validate_file_integrity(self, filename: str) -> bool:
        """Valida la integridad de un archivo comparando su hash"""
        if filename not in self.file_index:
            return False
        
        file_path = self.shared_directory / filename
        
        if not file_path.exists():
            return False
        
        try:
            current_hash = calculate_file_hash(str(file_path))
            expected_hash = self.file_index[filename].hash
            return current_hash == expected_hash
        except Exception:
            return False


class EchoService:
    """Servicio ECO - retorna el mismo archivo que recibe"""
    
    def __init__(self, file_manager: FileManager):
        self.file_manager = file_manager
    
    async def echo_file(self, filename: str, data: bytes) -> bytes:
        """Procesa un archivo y lo retorna sin modificaciones"""
        # Simular procesamiento
        await asyncio.sleep(0.1)
        
        # Validar que el archivo existe
        file_info = await self.file_manager.write_file(f"echo_{filename}", data)
        
        # Retornar los mismos datos
        return data


class DummyService:
    """Servicio DUMMY - genera archivos de prueba"""
    
    def __init__(self, file_manager: FileManager):
        self.file_manager = file_manager
    
    async def generate_dummy_file(self, filename: str, size: int) -> bytes:
        """Genera un archivo dummy del tamaño especificado"""
        if size <= 0:
            raise ValueError("El tamaño debe ser mayor a 0")
        
        if size > 100 * 1024 * 1024:  # 100MB máximo
            raise ValueError("Tamaño demasiado grande para archivo dummy")
        
        # Generar contenido dummy
        content = b"DUMMY_DATA_" * (size // 11 + 1)
        content = content[:size]  # Truncar al tamaño exacto
        
        # Guardar archivo dummy
        dummy_filename = f"dummy_{filename}"
        file_info = await self.file_manager.write_file(dummy_filename, content)
        
        return content
    
    async def create_test_files(self, count: int = 5) -> List[FileInfo]:
        """Crea archivos de prueba para testing"""
        test_files = []
        
        for i in range(count):
            filename = f"test_file_{i}.txt"
            content = f"Contenido de prueba del archivo {i}\n" * (i + 1)
            data = content.encode('utf-8')
            
            file_info = await self.file_manager.write_file(filename, data)
            test_files.append(file_info)
        
        return test_files