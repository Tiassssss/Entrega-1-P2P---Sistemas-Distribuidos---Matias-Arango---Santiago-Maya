"""
Módulo principal del Pservidor (según diagrama)
Coordina: REST (/files, /search) y gRPC (Upload, Download)
"""
import asyncio
import signal
import sys
from datetime import datetime
from typing import Dict, List, Optional

from .file_manager.file_manager import FileManager
from .rest_api.rest_server import RestAPI
from .rpc_server.rpc_server import RPCServer
from ..common.models import PeerInfo, PeerStatus
from ..common.utils import setup_logging, get_local_ip, is_port_available
from ..config.config_manager import config_manager


class Directorio:
    """
    Directorio de peers conocidos en la red (funcionalidad del PEER MAESTRO)
    Implementa la función DIRECTORIO del diagrama
    """
    
    def __init__(self, peer_id: str):
        self.peer_id = peer_id
        self.peers: Dict[str, PeerInfo] = {}
        self.logger = setup_logging()
    
    def register_peer(self, peer_info: PeerInfo) -> None:
        """Registra un nuevo peer en el directorio"""
        self.peers[peer_info.peer_id] = peer_info
        self.logger.info(f"DIRECTORIO: Registered peer {peer_info.peer_id} at {peer_info.url}")
    
    def get_peer(self, peer_id: str) -> Optional[PeerInfo]:
        """Obtiene información de un peer específico"""
        return self.peers.get(peer_id)
    
    def get_active_peers(self) -> List[PeerInfo]:
        """Retorna lista de peers activos"""
        return [peer for peer in self.peers.values() if peer.status == PeerStatus.ACTIVE]
    
    def update_peer_heartbeat(self, peer_id: str, status: str, files_count: int) -> None:
        """Actualiza información de heartbeat de un peer"""
        if peer_id in self.peers:
            peer = self.peers[peer_id]
            peer.status = PeerStatus(status)
            peer.files_count = files_count
            peer.last_seen = datetime.now()
            self.logger.debug(f"DIRECTORIO: Updated heartbeat for peer {peer_id}")
    
    def remove_peer(self, peer_id: str) -> bool:
        """Remueve un peer del directorio"""
        if peer_id in self.peers:
            del self.peers[peer_id]
            self.logger.info(f"DIRECTORIO: Removed peer {peer_id}")
            return True
        return False
    
    def cleanup_inactive_peers(self, timeout_minutes: int = 10) -> None:
        """Remueve peers que no han enviado heartbeat por un tiempo"""
        current_time = datetime.now()
        inactive_peers = []
        
        for peer_id, peer in self.peers.items():
            time_diff = (current_time - peer.last_seen).total_seconds() / 60
            if time_diff > timeout_minutes:
                inactive_peers.append(peer_id)
        
        for peer_id in inactive_peers:
            self.remove_peer(peer_id)
    
    def bootstrap_from_config(self) -> None:
        """Carga peers iniciales desde configuración"""
        config = config_manager.get_config()
        
        for i, peer_url in enumerate(config.peers.bootstrap_peers):
            # Parsear URL para extraer IP y puerto
            if peer_url.startswith('http://'):
                address_port = peer_url[7:]  # Remover 'http://'
                if ':' in address_port:
                    address, port_str = address_port.split(':')
                    port = int(port_str)
                else:
                    address = address_port
                    port = 8080
                
                peer_info = PeerInfo(
                    peer_id=f"bootstrap_peer_{i}",
                    address=address,
                    port=port,
                    rpc_port=port + 1,
                    status=PeerStatus.UNKNOWN,
                    files_count=0,
                    last_seen=datetime.now()
                )
                
                self.register_peer(peer_info)


class Pservidor:
    """
    Servidor P2P según diagrama
    Implementa: REST (/files, /search) y gRPC (Upload, Download)
    """
    
    def __init__(self):
        self.config = config_manager.get_config()
        self.logger = setup_logging(
            log_level=self.config.logging.level,
            log_file=self.config.logging.file
        )
        
        # Componentes principales según diagrama
        self.directorio = Directorio(self.config.peer_id)  # DIRECTORIO function
        self.file_manager = FileManager(
            self.config.storage.shared_directory,
            self.config.peer_id
        )
        self.rest_api = RestAPI(self.file_manager, self.directorio)  # REST (/files, /search)
        self.rpc_server = RPCServer(self.file_manager, self.directorio)  # gRPC (Upload, Download)
        
        # Estado del servidor
        self.running = False
        self.tasks = []
        
        # Aliases para compatibilidad
        self.peer_registry = self.directorio
    
    async def initialize(self) -> None:
        """Inicializa el servidor y todos sus componentes"""
        self.logger.info(f"Initializing Pservidor {self.config.peer_id}")
        
        # Verificar puertos disponibles
        if not is_port_available(self.config.network.listen_port):
            raise Exception(f"Puerto {self.config.network.listen_port} no disponible")
        
        if not is_port_available(self.config.network.rpc_port):
            raise Exception(f"Puerto RPC {self.config.network.rpc_port} no disponible")
        
        # Escanear archivos iniciales
        self.logger.info("Scanning shared files...")
        files = await self.file_manager.scan_files()
        self.logger.info(f"Found {len(files)} files in shared directory")
        
        # Cargar peers bootstrap
        self.directorio.bootstrap_from_config()
        self.logger.info(f"Loaded {len(self.directorio.get_active_peers())} bootstrap peers")
        
        self.logger.info("PServidor initialized successfully")
    
    async def start(self) -> None:
        """Inicia el servidor y todos sus servicios"""
        if self.running:
            self.logger.warning("Server is already running")
            return
        
        self.logger.info("Starting PServidor...")
        self.running = True
        
        # Configurar manejo de señales
        self._setup_signal_handlers()
        
        try:
            # Inicializar componentes
            await self.initialize()
            
            # Crear tareas para los servidores
            rest_task = asyncio.create_task(
                self.rest_api.start_server(
                    self.config.network.listen_ip,
                    self.config.network.listen_port
                )
            )
            
            rpc_task = asyncio.create_task(
                self.rpc_server.start_server(
                    self.config.network.listen_ip,
                    self.config.network.rpc_port
                )
            )
            
            # Tarea de mantenimiento
            maintenance_task = asyncio.create_task(self._maintenance_loop())
            
            self.tasks = [rest_task, rpc_task, maintenance_task]
            
            self.logger.info(f"PServidor started successfully")
            self.logger.info(f"REST API: http://{get_local_ip()}:{self.config.network.listen_port}")
            self.logger.info(f"RPC Server: {get_local_ip()}:{self.config.network.rpc_port}")
            
            # Esperar por todas las tareas
            await asyncio.gather(*self.tasks, return_exceptions=True)
            
        except Exception as e:
            self.logger.error(f"Error starting server: {e}")
            await self.stop()
            raise
    
    async def stop(self) -> None:
        """Detiene el servidor y todos sus servicios"""
        if not self.running:
            return
        
        self.logger.info("Stopping PServidor...")
        self.running = False
        
        # Cancelar todas las tareas
        for task in self.tasks:
            if not task.done():
                task.cancel()
        
        # Esperar que las tareas terminen
        if self.tasks:
            await asyncio.gather(*self.tasks, return_exceptions=True)
        
        # Detener servidor RPC
        await self.rpc_server.stop_server()
        
        self.logger.info("PServidor stopped")
    
    async def _maintenance_loop(self) -> None:
        """Loop de mantenimiento para tareas periódicas"""
        while self.running:
            try:
                # Limpiar peers inactivos cada 5 minutos
                self.directorio.cleanup_inactive_peers(timeout_minutes=5)
                
                # Re-escanear archivos cada 10 minutos
                await asyncio.sleep(600)  # 10 minutos
                if self.running:
                    files = await self.file_manager.scan_files()
                    self.logger.debug(f"Maintenance scan found {len(files)} files")
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Error in maintenance loop: {e}")
                await asyncio.sleep(60)  # Esperar 1 minuto antes de reintentar
    
    def _setup_signal_handlers(self) -> None:
        """Configura manejadores de señales para shutdown graceful"""
        if sys.platform != 'win32':
            def signal_handler():
                self.logger.info("Received shutdown signal")
                asyncio.create_task(self.stop())
            
            loop = asyncio.get_event_loop()
            loop.add_signal_handler(signal.SIGINT, signal_handler)
            loop.add_signal_handler(signal.SIGTERM, signal_handler)
    
    def get_status(self) -> dict:
        """Retorna el estado actual del servidor"""
        return {
            "peer_id": self.config.peer_id,
            "running": self.running,
            "files_count": len(self.file_manager.get_files()),
            "peers_count": len(self.directorio.get_active_peers()),
            "rest_port": self.config.network.listen_port,
            "rpc_port": self.config.network.rpc_port,
            "local_ip": get_local_ip()
        }


async def main():
    """Función principal para ejecutar el servidor"""
    try:
        # Crear instancia del servidor
        servidor = PServidor()
        
        # Iniciar servidor
        await servidor.start()
        
    except KeyboardInterrupt:
        print("\nShutdown requested by user")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())