"""
API REST para el servidor P2P
Proporciona endpoints para consulta y transferencia de archivos
"""
import asyncio
from fastapi import FastAPI, HTTPException, UploadFile, File, Query, Request
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
import uvicorn
from pathlib import Path
import io

from ..file_manager.file_manager import FileManager, EchoService, DummyService
from ...common.models import FileInfo, PeerInfo, APIResponse
from ...common.utils import RateLimiter, setup_logging
from ...config.config_manager import config_manager


class RestAPI:
    """Servidor REST API para el peer P2P"""
    
    def __init__(self, file_manager: FileManager, peer_registry):
        self.app = FastAPI(
            title="P2P Peer API",
            description="API REST para peer P2P - Comunicación y transferencia de archivos",
            version="1.0.0"
        )
        
        self.file_manager = file_manager
        self.peer_registry = peer_registry
        self.echo_service = EchoService(file_manager)
        self.dummy_service = DummyService(file_manager)
        
        # Rate limiter para prevenir spam
        self.rate_limiter = RateLimiter(max_requests=100, time_window=60)
        
        self._setup_middleware()
        self._setup_routes()
        
        # Logger
        self.logger = setup_logging()
    
    def _setup_middleware(self):
        """Configura middleware para CORS y otros"""
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
    
    def _setup_routes(self):
        """Configura las rutas de la API"""
        
        @self.app.get("/")
        async def root():
            """Endpoint raíz - información del peer"""
            config = config_manager.get_config()
            return APIResponse.success({
                "peer_id": config.peer_id,
                "status": "active",
                "files_count": len(self.file_manager.get_files()),
                "api_version": "1.0.0"
            })
        
        @self.app.get("/api/files", response_model=dict)
        async def list_files(request: Request, query: Optional[str] = Query(None)):
            """Lista todos los archivos disponibles o busca por query"""
            
            # Rate limiting
            client_ip = request.client.host
            if not self.rate_limiter.is_allowed(client_ip):
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
            
            try:
                if query:
                    files = self.file_manager.search_files(query)
                else:
                    files = self.file_manager.get_files()
                
                files_data = [file_info.to_dict() for file_info in files]
                
                return APIResponse.success(
                    data=files_data,
                    message=f"Found {len(files)} files"
                )
                
            except Exception as e:
                self.logger.error(f"Error listing files: {e}")
                raise HTTPException(status_code=500, detail="Internal server error")
        
        @self.app.get("/api/files/{filename}")
        async def download_file(filename: str, request: Request):
            """Descarga un archivo específico"""
            
            # Rate limiting
            client_ip = request.client.host
            if not self.rate_limiter.is_allowed(client_ip):
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
            
            try:
                file_info = self.file_manager.get_file_info(filename)
                if not file_info:
                    raise HTTPException(status_code=404, detail="File not found")
                
                file_path = self.file_manager.get_file_path(filename)
                if not file_path or not file_path.exists():
                    raise HTTPException(status_code=404, detail="File not found on disk")
                
                # Verificar integridad del archivo
                if not await self.file_manager.validate_file_integrity(filename):
                    raise HTTPException(status_code=500, detail="File integrity check failed")
                
                return FileResponse(
                    path=str(file_path),
                    filename=filename,
                    media_type='application/octet-stream'
                )
                
            except HTTPException:
                raise
            except Exception as e:
                self.logger.error(f"Error downloading file {filename}: {e}")
                raise HTTPException(status_code=500, detail="Internal server error")
        
        @self.app.get("/api/files/{filename}/info")
        async def get_file_info(filename: str, request: Request):
            """Obtiene información de un archivo específico"""
            
            # Rate limiting
            client_ip = request.client.host
            if not self.rate_limiter.is_allowed(client_ip):
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
            
            try:
                file_info = self.file_manager.get_file_info(filename)
                if not file_info:
                    raise HTTPException(status_code=404, detail="File not found")
                
                return APIResponse.success(data=file_info.to_dict())
                
            except HTTPException:
                raise
            except Exception as e:
                self.logger.error(f"Error getting file info {filename}: {e}")
                raise HTTPException(status_code=500, detail="Internal server error")
        
        @self.app.post("/api/files")
        async def upload_file(request: Request, file: UploadFile = File(...)):
            """Sube un archivo al peer"""
            
            # Rate limiting
            client_ip = request.client.host
            if not self.rate_limiter.is_allowed(client_ip):
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
            
            try:
                # Leer contenido del archivo
                content = await file.read()
                
                # Guardar archivo
                file_info = await self.file_manager.write_file(file.filename, content)
                
                return APIResponse.success(
                    data=file_info.to_dict(),
                    message=f"File {file.filename} uploaded successfully"
                )
                
            except ValueError as e:
                raise HTTPException(status_code=400, detail=str(e))
            except Exception as e:
                self.logger.error(f"Error uploading file {file.filename}: {e}")
                raise HTTPException(status_code=500, detail="Internal server error")
        
        @self.app.delete("/api/files/{filename}")
        async def delete_file(filename: str, request: Request):
            """Elimina un archivo del peer"""
            
            # Rate limiting
            client_ip = request.client.host
            if not self.rate_limiter.is_allowed(client_ip):
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
            
            try:
                success = await self.file_manager.delete_file(filename)
                
                if success:
                    return APIResponse.success(message=f"File {filename} deleted successfully")
                else:
                    raise HTTPException(status_code=404, detail="File not found")
                
            except HTTPException:
                raise
            except Exception as e:
                self.logger.error(f"Error deleting file {filename}: {e}")
                raise HTTPException(status_code=500, detail="Internal server error")
        
        @self.app.get("/api/peers")
        async def list_peers(request: Request):
            """Lista todos los peers conocidos"""
            
            # Rate limiting
            client_ip = request.client.host
            if not self.rate_limiter.is_allowed(client_ip):
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
            
            try:
                peers = self.peer_registry.get_active_peers()
                peers_data = [peer.to_dict() for peer in peers]
                
                return APIResponse.success(
                    data=peers_data,
                    message=f"Found {len(peers)} active peers"
                )
                
            except Exception as e:
                self.logger.error(f"Error listing peers: {e}")
                raise HTTPException(status_code=500, detail="Internal server error")
        
        @self.app.post("/api/peers/register")
        async def register_peer(request: Request, peer_data: dict):
            """Registra un nuevo peer en la red"""
            
            # Rate limiting
            client_ip = request.client.host
            if not self.rate_limiter.is_allowed(client_ip):
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
            
            try:
                # Crear objeto PeerInfo desde los datos recibidos
                peer_info = PeerInfo(
                    peer_id=peer_data.get('peer_id'),
                    address=peer_data.get('address'),
                    port=peer_data.get('port'),
                    rpc_port=peer_data.get('rpc_port'),
                    status=peer_data.get('status', 'active'),
                    files_count=peer_data.get('files_count', 0),
                    last_seen=datetime.now()
                )
                
                self.peer_registry.register_peer(peer_info)
                
                return APIResponse.success(
                    data=peer_info.to_dict(),
                    message=f"Peer {peer_info.peer_id} registered successfully"
                )
                
            except Exception as e:
                self.logger.error(f"Error registering peer: {e}")
                raise HTTPException(status_code=500, detail="Internal server error")
        
        @self.app.get("/api/search")
        async def search_network(request: Request, q: str = Query(...)):
            """Busca archivos en la red P2P"""
            
            # Rate limiting
            client_ip = request.client.host
            if not self.rate_limiter.is_allowed(client_ip):
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
            
            try:
                # Primero buscar localmente
                local_results = self.file_manager.search_files(q)
                
                # TODO: Implementar búsqueda en otros peers
                # network_results = await self.peer_registry.search_network(q)
                
                results_data = [file_info.to_dict() for file_info in local_results]
                
                return APIResponse.success(
                    data=results_data,
                    message=f"Found {len(local_results)} files matching '{q}'"
                )
                
            except Exception as e:
                self.logger.error(f"Error searching network: {e}")
                raise HTTPException(status_code=500, detail="Internal server error")
        
        # Servicios ECO y DUMMY
        @self.app.post("/api/services/echo/{filename}")
        async def echo_service(filename: str, request: Request, file: UploadFile = File(...)):
            """Servicio ECO - retorna el mismo archivo"""
            
            # Rate limiting
            client_ip = request.client.host
            if not self.rate_limiter.is_allowed(client_ip):
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
            
            try:
                content = await file.read()
                result = await self.echo_service.echo_file(filename, content)
                
                return StreamingResponse(
                    io.BytesIO(result),
                    media_type='application/octet-stream',
                    headers={"Content-Disposition": f"attachment; filename=echo_{filename}"}
                )
                
            except Exception as e:
                self.logger.error(f"Error in echo service: {e}")
                raise HTTPException(status_code=500, detail="Internal server error")
        
        @self.app.post("/api/services/dummy/{filename}")
        async def dummy_service(filename: str, request: Request, size: int = Query(...)):
            """Servicio DUMMY - genera archivo de prueba"""
            
            # Rate limiting
            client_ip = request.client.host
            if not self.rate_limiter.is_allowed(client_ip):
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
            
            try:
                result = await self.dummy_service.generate_dummy_file(filename, size)
                
                return StreamingResponse(
                    io.BytesIO(result),
                    media_type='application/octet-stream',
                    headers={"Content-Disposition": f"attachment; filename=dummy_{filename}"}
                )
                
            except ValueError as e:
                raise HTTPException(status_code=400, detail=str(e))
            except Exception as e:
                self.logger.error(f"Error in dummy service: {e}")
                raise HTTPException(status_code=500, detail="Internal server error")
        
        @self.app.post("/api/rescan")
        async def rescan_files(request: Request):
            """Re-escanea el directorio de archivos compartidos"""
            
            # Rate limiting
            client_ip = request.client.host
            if not self.rate_limiter.is_allowed(client_ip):
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
            
            try:
                files = await self.file_manager.scan_files()
                files_data = [file_info.to_dict() for file_info in files]
                
                return APIResponse.success(
                    data=files_data,
                    message=f"Rescanned directory, found {len(files)} files"
                )
                
            except Exception as e:
                self.logger.error(f"Error rescanning files: {e}")
                raise HTTPException(status_code=500, detail="Internal server error")
    
    async def start_server(self, host: str = "0.0.0.0", port: int = 8080):
        """Inicia el servidor REST API"""
        self.logger.info(f"Starting REST API server on {host}:{port}")
        
        config = uvicorn.Config(
            app=self.app,
            host=host,
            port=port,
            log_level="info"
        )
        
        server = uvicorn.Server(config)
        await server.serve()
    
    def run_server(self, host: str = "0.0.0.0", port: int = 8080):
        """Ejecuta el servidor de forma síncrona"""
        uvicorn.run(self.app, host=host, port=port)