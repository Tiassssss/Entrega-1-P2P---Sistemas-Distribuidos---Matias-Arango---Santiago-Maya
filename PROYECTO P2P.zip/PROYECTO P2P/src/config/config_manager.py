"""
Módulo de configuración del sistema P2P
Maneja la carga y validación de configuraciones de peers
"""
import json
import os
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class NetworkConfig:
    listen_ip: str
    listen_port: int
    rpc_port: int
    max_connections: int


@dataclass
class StorageConfig:
    shared_directory: str
    max_file_size: str
    allowed_extensions: List[str]


@dataclass
class PeersConfig:
    bootstrap_peers: List[str]
    backup_peers: List[str]


@dataclass
class SecurityConfig:
    enable_auth: bool
    api_key: Optional[str]


@dataclass
class LoggingConfig:
    level: str
    file: str


@dataclass
class PeerConfig:
    peer_id: str
    network: NetworkConfig
    storage: StorageConfig
    peers: PeersConfig
    security: SecurityConfig
    logging: LoggingConfig


class ConfigManager:
    """Gestor de configuración para peers P2P"""
    
    def __init__(self, config_path: str = "src/config/peer_config.json"):
        self.config_path = config_path
        self._config: Optional[PeerConfig] = None
    
    def load_config(self) -> PeerConfig:
        """Carga la configuración desde archivo JSON"""
        if not os.path.exists(self.config_path):
            raise FileNotFoundError(f"Archivo de configuración no encontrado: {self.config_path}")
        
        with open(self.config_path, 'r', encoding='utf-8') as file:
            config_data = json.load(file)
        
        self._config = PeerConfig(
            peer_id=config_data['peer_id'],
            network=NetworkConfig(**config_data['network']),
            storage=StorageConfig(**config_data['storage']),
            peers=PeersConfig(**config_data['peers']),
            security=SecurityConfig(**config_data['security']),
            logging=LoggingConfig(**config_data['logging'])
        )
        
        return self._config
    
    def get_config(self) -> PeerConfig:
        """Retorna la configuración cargada"""
        if self._config is None:
            return self.load_config()
        return self._config
    
    def update_peers(self, new_peers: List[str]) -> None:
        """Actualiza la lista de peers conocidos"""
        if self._config:
            self._config.peers.bootstrap_peers.extend(new_peers)
            # Eliminar duplicados
            self._config.peers.bootstrap_peers = list(set(self._config.peers.bootstrap_peers))
    
    def save_config(self) -> None:
        """Guarda la configuración actual al archivo"""
        if self._config is None:
            raise ValueError("No hay configuración cargada para guardar")
        
        config_dict = {
            "peer_id": self._config.peer_id,
            "network": {
                "listen_ip": self._config.network.listen_ip,
                "listen_port": self._config.network.listen_port,
                "rpc_port": self._config.network.rpc_port,
                "max_connections": self._config.network.max_connections
            },
            "storage": {
                "shared_directory": self._config.storage.shared_directory,
                "max_file_size": self._config.storage.max_file_size,
                "allowed_extensions": self._config.storage.allowed_extensions
            },
            "peers": {
                "bootstrap_peers": self._config.peers.bootstrap_peers,
                "backup_peers": self._config.peers.backup_peers
            },
            "security": {
                "enable_auth": self._config.security.enable_auth,
                "api_key": self._config.security.api_key
            },
            "logging": {
                "level": self._config.logging.level,
                "file": self._config.logging.file
            }
        }
        
        with open(self.config_path, 'w', encoding='utf-8') as file:
            json.dump(config_dict, file, indent=4, ensure_ascii=False)


# Instancia global del gestor de configuración
config_manager = ConfigManager()