# Especificación Técnica - Sistema P2P

## 1. Arquitectura de Red P2P

### Modelo de Red No Estructurada
- Sin servidor de directorio centralizado
- Cada peer mantiene lista de peers conocidos
- Descubrimiento mediante bootstrap y propagación
- Tolerancia a fallos distribuida

### Topología de Conexiones
- Cada peer mantiene conexiones con 3-5 peers vecinos
- Sistema de heartbeat para detectar peers caídos
- Reemplazo automático de peers no disponibles

## 2. Especificación de Microservicios

### 2.1 PServidor - Módulos Servidor

#### Consulta de Archivos (FileQueryService)
```python
class FileQueryService:
    def list_files() -> List[FileInfo]
    def search_file(filename: str) -> Optional[FileInfo]
    def get_file_metadata(filename: str) -> FileMetadata
```

#### Transferencia de Archivos (FileTransferService)
```python
class FileTransferService:
    def download_file(filename: str) -> bytes
    def upload_file(filename: str, data: bytes) -> bool
    def get_file_chunk(filename: str, start: int, size: int) -> bytes
```

#### Gestión de Concurrencia
- Pool de hilos para manejar múltiples conexiones simultáneas
- Límite de 10 conexiones concurrentes por peer
- Queue de peticiones con prioridad para transferencias

### 2.2 PCliente - Módulo Cliente

#### Descubrimiento de Peers (PeerDiscovery)
```python
class PeerDiscovery:
    def bootstrap() -> List[PeerInfo]
    def find_peers() -> List[PeerInfo]
    def register_with_peer(peer_address: str) -> bool
```

#### Búsqueda Distribuida (DistributedSearch)
```python
class DistributedSearch:
    def search_file_network(filename: str) -> List[PeerFileInfo]
    def propagate_search(query: SearchQuery, ttl: int) -> List[Result]
```

## 3. Protocolos de Comunicación

### 3.1 API REST

#### Endpoints del Servidor
| Método | Endpoint | Descripción | Parámetros |
|--------|----------|-------------|------------|
| GET | `/api/files` | Lista archivos disponibles | query: filtro opcional |
| GET | `/api/files/{filename}` | Descarga archivo | filename: nombre del archivo |
| POST | `/api/files` | Sube archivo | multipart/form-data |
| GET | `/api/peers` | Lista peers conocidos | - |
| POST | `/api/peers/register` | Registra nuevo peer | peer_info: JSON |
| GET | `/api/search` | Busca archivo en red | q: término de búsqueda |

#### Formatos de Respuesta
```json
// FileInfo
{
    "filename": "document.pdf",
    "size": 1024000,
    "hash": "sha256:abc123...",
    "peer_id": "peer_001",
    "last_modified": "2025-09-17T10:30:00Z"
}

// PeerInfo
{
    "peer_id": "peer_001",
    "address": "192.168.1.100",
    "port": 8080,
    "status": "active",
    "files_count": 15
}
```

### 3.2 RPC (Remote Procedure Call)

#### Servicios RPC
```protobuf
service P2PService {
    rpc SearchFile(SearchRequest) returns (SearchResponse);
    rpc DownloadFile(DownloadRequest) returns (stream FileChunk);
    rpc UploadFile(stream FileChunk) returns (UploadResponse);
    rpc GetPeers(Empty) returns (PeerList);
    rpc Heartbeat(PeerInfo) returns (HeartbeatResponse);
}
```

## 4. Gestión de Archivos

### 4.1 Estructura de Datos
```python
@dataclass
class FileMetadata:
    filename: str
    size: int
    hash: str
    created_at: datetime
    modified_at: datetime
    peer_id: str
    chunks: List[ChunkInfo]

@dataclass
class ChunkInfo:
    chunk_id: str
    offset: int
    size: int
    hash: str
```

### 4.2 Servicios ECO y DUMMY

#### Servicio ECO
- Retorna el mismo archivo que recibe
- Útil para pruebas de conectividad
- Validación de integridad

#### Servicio DUMMY
- Genera archivos de prueba de tamaño específico
- Simula transferencias sin usar archivos reales
- Benchmarking de rendimiento

## 5. Configuración del Sistema

### 5.1 Archivo de Configuración Bootstrap
```json
{
    "peer_id": "peer_001",
    "network": {
        "listen_ip": "0.0.0.0",
        "listen_port": 8080,
        "rpc_port": 8081,
        "max_connections": 50
    },
    "storage": {
        "shared_directory": "./shared_files",
        "max_file_size": "100MB",
        "allowed_extensions": [".pdf", ".txt", ".jpg", ".png"]
    },
    "peers": {
        "bootstrap_peers": [
            "http://192.168.1.10:8080",
            "http://192.168.1.11:8080"
        ],
        "backup_peers": [
            "http://192.168.1.20:8080"
        ]
    },
    "security": {
        "enable_auth": false,
        "api_key": null
    }
}
```

## 6. Manejo de Fallos y Tolerancia

### Estrategias de Recuperación
1. **Peer Failure**: Reintento con peers alternativos
2. **Network Partition**: Reconexión automática
3. **File Corruption**: Verificación de hash
4. **Timeout**: Configuración de timeouts adaptativos

### Logging y Monitoreo
- Logs estructurados en formato JSON
- Métricas de rendimiento (latencia, throughput)
- Estado de salud de peers

## 7. Seguridad

### Consideraciones Básicas
- Validación de archivos subidos
- Límites de tasa para prevenir spam
- Filtrado de extensiones peligrosas
- Aislamiento de procesos

## 8. Testing y Validación

### Tipos de Pruebas
1. **Pruebas Unitarias**: Cada microservicio individualmente
2. **Pruebas de Integración**: Comunicación entre componentes
3. **Pruebas de Red**: Múltiples peers interactuando
4. **Pruebas de Carga**: Concurrencia y rendimiento
5. **Pruebas de Fallos**: Simulación de errores de red