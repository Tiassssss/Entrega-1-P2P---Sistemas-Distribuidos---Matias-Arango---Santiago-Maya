#!/bin/bash

# Script para ejecutar el sistema P2P localmente

echo "=== Iniciando Sistema P2P Local ==="

# Función para limpiar procesos al salir
cleanup() {
    echo "Deteniendo peers..."
    pkill -f "p2p_node.py"
    exit 0
}

trap cleanup SIGINT SIGTERM

# Verificar que el setup se haya ejecutado
if [ ! -f "src/pservidor/rpc_server/p2p_pb2.py" ]; then
    echo "Ejecutando setup inicial..."
    ./setup.sh
fi

# Iniciar peer principal en background
echo "Iniciando peer principal (puerto 8080)..."
python src/p2p_node.py > logs/peer1.log 2>&1 &
PEER1_PID=$!

sleep 3

# Iniciar peer 2 en background
echo "Iniciando peer 2 (puerto 8082)..."
python src/p2p_node.py --config src/config/peer2_config.json > logs/peer2.log 2>&1 &
PEER2_PID=$!

sleep 3

# Iniciar peer 3 en background
echo "Iniciando peer 3 (puerto 8084)..."
python src/p2p_node.py --config src/config/peer3_config.json > logs/peer3.log 2>&1 &
PEER3_PID=$!

sleep 3

echo "=== Peers iniciados ==="
echo "Peer 1: http://localhost:8080 (PID: $PEER1_PID)"
echo "Peer 2: http://localhost:8082 (PID: $PEER2_PID)"
echo "Peer 3: http://localhost:8084 (PID: $PEER3_PID)"
echo ""
echo "Logs disponibles en:"
echo "- logs/peer1.log"
echo "- logs/peer2.log"
echo "- logs/peer3.log"
echo ""
echo "APIs REST disponibles:"
echo "- http://localhost:8080/api/files"
echo "- http://localhost:8082/api/files"
echo "- http://localhost:8084/api/files"
echo ""
echo "Presiona Ctrl+C para detener todos los peers"

# Esperar indefinidamente
wait