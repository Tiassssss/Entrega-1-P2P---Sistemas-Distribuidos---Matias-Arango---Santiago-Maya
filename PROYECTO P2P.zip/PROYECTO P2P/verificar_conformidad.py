#!/usr/bin/env python3
"""
Verificación de Conformidad con el Diagrama de Arquitectura
Valida que cada componente implementado coincida exactamente con el diseño mostrado
"""
import sys
from pathlib import Path

# Agregar el directorio raíz al path
sys.path.append(str(Path(__file__).parent))

def verificar_estructura_proyecto():
    """Verifica que la estructura del proyecto coincida con el diagrama"""
    print("🔍 VERIFICANDO ESTRUCTURA DEL PROYECTO")
    print("=" * 50)
    
    # Estructura esperada según diagrama
    estructura_esperada = {
        "src/pservidor/": [
            "pservidor.py",           # Coordinador principal
            "file_manager/",          # Gestión de archivos
            "rest_api/",             # REST endpoints (/files, /search)
            "rpc_server/"            # gRPC (Upload/Download)
        ],
        "src/pcliente/": [
            "pcliente.py",           # Coordinador principal
            "rest_client.py",        # Cliente REST
            "rpc_client.py"          # Cliente gRPC
        ],
        "src/": [
            "p2p_node.py",          # Nodo P2P completo
            "config/",              # Configuraciones
            "common/"               # Modelos compartidos
        ]
    }
    
    errores = []
    for directorio, archivos in estructura_esperada.items():
        dir_path = Path(directorio)
        if not dir_path.exists():
            errores.append(f"❌ Directorio faltante: {directorio}")
            continue
        
        for archivo in archivos:
            archivo_path = dir_path / archivo
            if not archivo_path.exists():
                errores.append(f"❌ Archivo/directorio faltante: {archivo_path}")
            else:
                print(f"✅ {archivo_path}")
    
    if errores:
        print("\n⚠️  ERRORES ENCONTRADOS:")
        for error in errores:
            print(error)
        return False
    else:
        print("\n✅ ESTRUCTURA PROYECTO: CONFORME CON DIAGRAMA")
        return True

def verificar_componente_pservidor():
    """Verifica que PServidor implemente los elementos del diagrama"""
    print("\n🖥️  VERIFICANDO COMPONENTE PSERVIDOR")
    print("=" * 50)
    
    verificaciones = []
    
    try:
        # Importar PServidor
        from src.pservidor.pservidor import PServidor
        verificaciones.append("✅ PServidor: Clase principal existe")
        
        # Verificar REST API endpoints
        from src.pservidor.rest_api.rest_server import RestAPI
        verificaciones.append("✅ REST API: Módulo implementado")
        
        # Leer el código REST para verificar endpoints específicos
        rest_code = Path("src/pservidor/rest_api/rest_server.py").read_text()
        if "/api/files" in rest_code:
            verificaciones.append("✅ REST: /files endpoint implementado")
        else:
            verificaciones.append("❌ REST: /files endpoint faltante")
            
        if "/api/search" in rest_code:
            verificaciones.append("✅ REST: /search endpoint implementado")
        else:
            verificaciones.append("❌ REST: /search endpoint faltante")
        
        # Verificar gRPC server
        from src.pservidor.rpc_server.rpc_server import RPCServer
        verificaciones.append("✅ gRPC: Servidor implementado")
        
        # Leer el código RPC para verificar métodos específicos
        rpc_code = Path("src/pservidor/rpc_server/rpc_server.py").read_text()
        if "UploadFile" in rpc_code:
            verificaciones.append("✅ gRPC: Upload method implementado")
        else:
            verificaciones.append("❌ gRPC: Upload method faltante")
            
        if "DownloadFile" in rpc_code:
            verificaciones.append("✅ gRPC: Download method implementado")
        else:
            verificaciones.append("❌ gRPC: Download method faltante")
        
        # Verificar FileManager
        from src.pservidor.file_manager.file_manager import FileManager
        verificaciones.append("✅ FileManager: Gestión de archivos implementada")
        
    except ImportError as e:
        verificaciones.append(f"❌ Error importando PServidor: {e}")
    
    for verificacion in verificaciones:
        print(verificacion)
    
    exitos = len([v for v in verificaciones if v.startswith("✅")])
    total = len(verificaciones)
    print(f"\n📊 PServidor: {exitos}/{total} componentes verificados")
    
    return exitos == total

def verificar_componente_pcliente():
    """Verifica que PCliente implemente los elementos del diagrama"""
    print("\n📱 VERIFICANDO COMPONENTE PCLIENTE")
    print("=" * 50)
    
    verificaciones = []
    
    try:
        # Importar PCliente
        from src.pcliente.pcliente import PCliente
        verificaciones.append("✅ PCliente: Clase principal existe")
        
        # Leer código para verificar funcionalidades específicas del diagrama
        pcliente_code = Path("src/pcliente/pcliente.py").read_text()
        
        # Verificar "Consulta maestro"
        if "bootstrap" in pcliente_code.lower() or "maestro" in pcliente_code.lower():
            verificaciones.append("✅ PCliente: Consulta maestro implementada")
        else:
            verificaciones.append("❌ PCliente: Consulta maestro faltante")
        
        # Verificar "Consulta Peers"
        if "search" in pcliente_code.lower() and "network" in pcliente_code.lower():
            verificaciones.append("✅ PCliente: Consulta Peers implementada")
        else:
            verificaciones.append("❌ PCliente: Consulta Peers faltante")
        
        # Verificar "Solicita Upload"
        if "upload" in pcliente_code.lower():
            verificaciones.append("✅ PCliente: Solicita Upload implementado")
        else:
            verificaciones.append("❌ PCliente: Solicita Upload faltante")
        
        # Verificar "Solicita Download"
        if "download" in pcliente_code.lower():
            verificaciones.append("✅ PCliente: Solicita Download implementado")
        else:
            verificaciones.append("❌ PCliente: Solicita Download faltante")
        
        # Verificar clientes REST y RPC
        from src.pcliente.rest_client import RestClient
        verificaciones.append("✅ REST Client: Implementado")
        
        from src.pcliente.rpc_client import RPCClient
        verificaciones.append("✅ RPC Client: Implementado")
        
    except ImportError as e:
        verificaciones.append(f"❌ Error importando PCliente: {e}")
    
    for verificacion in verificaciones:
        print(verificacion)
    
    exitos = len([v for v in verificaciones if v.startswith("✅")])
    total = len(verificaciones)
    print(f"\n📊 PCliente: {exitos}/{total} componentes verificados")
    
    return exitos == total

def verificar_arquitectura_peer_maestro():
    """Verifica que se pueda configurar un PEER MAESTRO"""
    print("\n🎯 VERIFICANDO ARQUITECTURA PEER MAESTRO")
    print("=" * 50)
    
    verificaciones = []
    
    try:
        # Verificar que se puede crear un nodo como peer maestro
        from src.p2p_node import P2PNode
        verificaciones.append("✅ P2PNode: Clase implementada")
        
        # Verificar PeerRegistry para DIRECTORIO
        from src.pservidor.pservidor import PeerRegistry
        verificaciones.append("✅ PeerRegistry: DIRECTORIO implementado")
        
        # Verificar NetworkDiscovery para LOCALIZACIÓN
        from src.pcliente.pcliente import NetworkDiscovery
        verificaciones.append("✅ NetworkDiscovery: LOCALIZACIÓN implementada")
        
        # Verificar configuración
        from src.config.config_manager import config_manager
        verificaciones.append("✅ ConfigManager: Sistema de configuración")
        
        # Verificar que puede actuar como bootstrap
        p2p_code = Path("src/p2p_node.py").read_text()
        if "bootstrap" in p2p_code.lower():
            verificaciones.append("✅ P2PNode: Capacidad bootstrap/maestro")
        else:
            verificaciones.append("❌ P2PNode: Capacidad bootstrap faltante")
        
    except ImportError as e:
        verificaciones.append(f"❌ Error verificando arquitectura: {e}")
    
    for verificacion in verificaciones:
        print(verificacion)
    
    exitos = len([v for v in verificaciones if v.startswith("✅")])
    total = len(verificaciones)
    print(f"\n📊 Peer Maestro: {exitos}/{total} componentes verificados")
    
    return exitos == total

def verificar_protocolos_comunicacion():
    """Verifica que ambos protocolos (REST + gRPC) estén implementados"""
    print("\n🌐 VERIFICANDO PROTOCOLOS DE COMUNICACIÓN")
    print("=" * 50)
    
    verificaciones = []
    
    # Verificar REST
    rest_files = [
        "src/pservidor/rest_api/rest_server.py",
        "src/pcliente/rest_client.py"
    ]
    
    for file_path in rest_files:
        if Path(file_path).exists():
            verificaciones.append(f"✅ REST: {file_path}")
        else:
            verificaciones.append(f"❌ REST: {file_path} faltante")
    
    # Verificar gRPC/RPC
    rpc_files = [
        "src/pservidor/rpc_server/rpc_server.py",
        "src/pcliente/rpc_client.py"
    ]
    
    for file_path in rpc_files:
        if Path(file_path).exists():
            verificaciones.append(f"✅ gRPC: {file_path}")
        else:
            verificaciones.append(f"❌ gRPC: {file_path} faltante")
    
    # Verificar protobuf definitions
    proto_files = list(Path("src").glob("**/*.proto"))
    if proto_files:
        verificaciones.append(f"✅ Protobuf: {len(proto_files)} archivos .proto")
    else:
        verificaciones.append("⚠️  Protobuf: No se encontraron archivos .proto")
    
    for verificacion in verificaciones:
        print(verificacion)
    
    exitos = len([v for v in verificaciones if v.startswith("✅")])
    total = len(verificaciones)
    print(f"\n📊 Protocolos: {exitos}/{total} componentes verificados")
    
    return exitos >= total * 0.8  # 80% mínimo

def verificar_integracion_completa():
    """Verifica que todos los componentes estén integrados correctamente"""
    print("\n🔗 VERIFICANDO INTEGRACIÓN COMPLETA")
    print("=" * 50)
    
    verificaciones = []
    
    try:
        # Verificar que P2PNode integra ambos componentes
        p2p_code = Path("src/p2p_node.py").read_text()
        
        if "PServidor" in p2p_code and "PCliente" in p2p_code:
            verificaciones.append("✅ Integración: P2PNode incluye PServidor + PCliente")
        else:
            verificaciones.append("❌ Integración: P2PNode no integra ambos componentes")
        
        # Verificar scripts de ejecución
        scripts = ["setup.sh", "run_local.sh", "p2p_cli.py"]
        for script in scripts:
            if Path(script).exists():
                verificaciones.append(f"✅ Script: {script}")
            else:
                verificaciones.append(f"❌ Script: {script} faltante")
        
        # Verificar Docker support
        docker_files = ["docker/Dockerfile", "docker/docker-compose.yml"]
        docker_count = sum(1 for f in docker_files if Path(f).exists())
        if docker_count >= 1:
            verificaciones.append(f"✅ Docker: {docker_count}/2 archivos")
        else:
            verificaciones.append("❌ Docker: Sin soporte de contenedores")
        
        # Verificar documentación
        doc_files = ["README.md", "docs/informe-tecnico-final.md"]
        doc_count = sum(1 for f in doc_files if Path(f).exists())
        if doc_count >= 1:
            verificaciones.append(f"✅ Documentación: {doc_count}/2 archivos")
        else:
            verificaciones.append("❌ Documentación: Faltante")
        
    except Exception as e:
        verificaciones.append(f"❌ Error verificando integración: {e}")
    
    for verificacion in verificaciones:
        print(verificacion)
    
    exitos = len([v for v in verificaciones if v.startswith("✅")])
    total = len(verificaciones)
    print(f"\n📊 Integración: {exitos}/{total} componentes verificados")
    
    return exitos >= total * 0.8  # 80% mínimo

def generar_reporte_conformidad():
    """Genera reporte final de conformidad con el diagrama"""
    print("\n" + "="*80)
    print("📋 REPORTE FINAL DE CONFORMIDAD CON DIAGRAMA")
    print("="*80)
    
    resultados = {
        "Estructura Proyecto": verificar_estructura_proyecto(),
        "Componente PServidor": verificar_componente_pservidor(),
        "Componente PCliente": verificar_componente_pcliente(),
        "Arquitectura Peer Maestro": verificar_arquitectura_peer_maestro(),
        "Protocolos Comunicación": verificar_protocolos_comunicacion(),
        "Integración Completa": verificar_integracion_completa()
    }
    
    print("\n📊 RESUMEN DE CONFORMIDAD:")
    print("-" * 50)
    
    total_exitosos = 0
    total_categorias = len(resultados)
    
    for categoria, exito in resultados.items():
        status = "✅ CONFORME" if exito else "❌ NO CONFORME"
        print(f"{categoria:<30} {status}")
        if exito:
            total_exitosos += 1
    
    porcentaje = (total_exitosos / total_categorias) * 100
    print(f"\n🎯 CONFORMIDAD GENERAL: {total_exitosos}/{total_categorias} ({porcentaje:.1f}%)")
    
    if porcentaje >= 90:
        print("\n🎉 EXCELENTE: Implementación totalmente conforme con el diagrama")
        estado = "APROBADO"
    elif porcentaje >= 75:
        print("\n✅ BUENO: Implementación mayormente conforme, mejoras menores")
        estado = "APROBADO CON OBSERVACIONES"
    elif porcentaje >= 50:
        print("\n⚠️  REGULAR: Implementación parcialmente conforme, requiere ajustes")
        estado = "REQUIERE MODIFICACIONES"
    else:
        print("\n❌ INSUFICIENTE: Implementación no conforme, requiere rediseño")
        estado = "NO APROBADO"
    
    print(f"\n🏆 VEREDICTO FINAL: {estado}")
    print("="*80)
    
    return porcentaje >= 75

def main():
    """Función principal de verificación"""
    print("🔍 INICIANDO VERIFICACIÓN DE CONFORMIDAD CON DIAGRAMA")
    print("Validando que la implementación siga exactamente el diseño mostrado")
    print("\n")
    
    try:
        resultado = generar_reporte_conformidad()
        
        if resultado:
            print("\n✅ VERIFICACIÓN EXITOSA: Implementación conforme con diagrama")
            sys.exit(0)
        else:
            print("\n❌ VERIFICACIÓN FALLIDA: Implementación requiere ajustes")
            sys.exit(1)
    
    except Exception as e:
        print(f"\n💥 ERROR EN VERIFICACIÓN: {e}")
        sys.exit(2)

if __name__ == "__main__":
    main()