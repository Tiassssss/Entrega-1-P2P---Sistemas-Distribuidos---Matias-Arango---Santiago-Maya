"""
Pruebas de rendimiento y concurrencia para el sistema P2P
"""
import asyncio
import time
import statistics
import tempfile
import shutil
import sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import aiohttp

# Agregar el directorio raíz al path
sys.path.append(str(Path(__file__).parent.parent))

from src.pservidor.file_manager.file_manager import FileManager


class PerformanceTests:
    """Suite de pruebas de rendimiento"""
    
    def __init__(self):
        self.temp_dir = None
        self.file_manager = None
        self.results = {}
    
    def setup(self):
        """Configuración inicial"""
        self.temp_dir = tempfile.mkdtemp()
        self.file_manager = FileManager(self.temp_dir, "perf_test_peer")
    
    def teardown(self):
        """Limpieza"""
        if self.temp_dir:
            shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    async def test_file_write_performance(self, num_files=100, file_size=1024):
        """Prueba rendimiento de escritura de archivos"""
        print(f"📊 Testing file write performance: {num_files} files, {file_size} bytes each")
        
        start_time = time.time()
        
        tasks = []
        for i in range(num_files):
            filename = f"perf_test_{i}.txt"
            content = b"X" * file_size
            task = self.file_manager.write_file(filename, content)
            tasks.append(task)
        
        await asyncio.gather(*tasks)
        
        end_time = time.time()
        total_time = end_time - start_time
        
        files_per_second = num_files / total_time
        mbps = (num_files * file_size) / (total_time * 1024 * 1024)
        
        self.results['file_write'] = {
            'total_time': total_time,
            'files_per_second': files_per_second,
            'mbps': mbps,
            'num_files': num_files,
            'file_size': file_size
        }
        
        print(f"  ✓ Completed in {total_time:.2f}s")
        print(f"  ✓ {files_per_second:.1f} files/sec")
        print(f"  ✓ {mbps:.2f} MB/s")
    
    async def test_file_read_performance(self, num_files=100):
        """Prueba rendimiento de lectura de archivos"""
        print(f"📊 Testing file read performance: {num_files} files")
        
        start_time = time.time()
        
        tasks = []
        for i in range(num_files):
            filename = f"perf_test_{i}.txt"
            task = self.file_manager.read_file(filename)
            tasks.append(task)
        
        results = await asyncio.gather(*tasks)
        
        end_time = time.time()
        total_time = end_time - start_time
        
        files_per_second = num_files / total_time
        total_bytes = sum(len(data) for data in results)
        mbps = total_bytes / (total_time * 1024 * 1024)
        
        self.results['file_read'] = {
            'total_time': total_time,
            'files_per_second': files_per_second,
            'mbps': mbps,
            'num_files': num_files,
            'total_bytes': total_bytes
        }
        
        print(f"  ✓ Completed in {total_time:.2f}s")
        print(f"  ✓ {files_per_second:.1f} files/sec")
        print(f"  ✓ {mbps:.2f} MB/s")
    
    async def test_concurrent_access(self, num_workers=50, operations_per_worker=10):
        """Prueba acceso concurrente al sistema"""
        print(f"📊 Testing concurrent access: {num_workers} workers, {operations_per_worker} ops each")
        
        async def worker(worker_id):
            """Worker que realiza operaciones aleatorias"""
            latencies = []
            
            for op_id in range(operations_per_worker):
                start = time.time()
                
                # Alternar entre escritura y lectura
                if op_id % 2 == 0:
                    # Escribir archivo
                    filename = f"worker_{worker_id}_op_{op_id}.txt"
                    content = f"Worker {worker_id} operation {op_id}".encode()
                    await self.file_manager.write_file(filename, content)
                else:
                    # Leer archivo existente
                    try:
                        filename = f"worker_{worker_id}_op_{op_id-1}.txt"
                        await self.file_manager.read_file(filename)
                    except:
                        pass  # Ignorar errores de archivos no encontrados
                
                end = time.time()
                latencies.append(end - start)
            
            return latencies
        
        start_time = time.time()
        
        # Ejecutar workers concurrentemente
        tasks = [worker(i) for i in range(num_workers)]
        all_latencies = await asyncio.gather(*tasks)
        
        end_time = time.time()
        total_time = end_time - start_time
        
        # Calcular estadísticas
        flat_latencies = [lat for worker_lats in all_latencies for lat in worker_lats]
        
        avg_latency = statistics.mean(flat_latencies)
        p95_latency = statistics.quantiles(flat_latencies, n=20)[18]  # 95th percentile
        max_latency = max(flat_latencies)
        
        total_operations = num_workers * operations_per_worker
        ops_per_second = total_operations / total_time
        
        self.results['concurrent_access'] = {
            'total_time': total_time,
            'ops_per_second': ops_per_second,
            'avg_latency': avg_latency,
            'p95_latency': p95_latency,
            'max_latency': max_latency,
            'num_workers': num_workers,
            'operations_per_worker': operations_per_worker
        }
        
        print(f"  ✓ Completed in {total_time:.2f}s")
        print(f"  ✓ {ops_per_second:.1f} ops/sec")
        print(f"  ✓ Avg latency: {avg_latency*1000:.1f}ms")
        print(f"  ✓ P95 latency: {p95_latency*1000:.1f}ms")
        print(f"  ✓ Max latency: {max_latency*1000:.1f}ms")
    
    async def test_large_file_handling(self, file_size_mb=10):
        """Prueba manejo de archivos grandes"""
        print(f"📊 Testing large file handling: {file_size_mb}MB file")
        
        filename = f"large_file_{file_size_mb}mb.bin"
        file_size = file_size_mb * 1024 * 1024
        
        # Generar contenido grande
        chunk_size = 1024 * 1024  # 1MB chunks
        content = bytearray()
        
        for i in range(file_size_mb):
            chunk = b"LARGE_FILE_CHUNK_" + str(i).encode() + b"_" * (chunk_size - 20)
            content.extend(chunk[:chunk_size])
        
        content = bytes(content[:file_size])
        
        # Prueba de escritura
        start_time = time.time()
        await self.file_manager.write_file(filename, content)
        write_time = time.time() - start_time
        
        # Prueba de lectura
        start_time = time.time()
        read_content = await self.file_manager.read_file(filename)
        read_time = time.time() - start_time
        
        # Verificar integridad
        integrity_ok = len(read_content) == len(content) and read_content == content
        
        write_mbps = file_size_mb / write_time
        read_mbps = file_size_mb / read_time
        
        self.results['large_file'] = {
            'file_size_mb': file_size_mb,
            'write_time': write_time,
            'read_time': read_time,
            'write_mbps': write_mbps,
            'read_mbps': read_mbps,
            'integrity_ok': integrity_ok
        }
        
        print(f"  ✓ Write: {write_time:.2f}s ({write_mbps:.1f} MB/s)")
        print(f"  ✓ Read: {read_time:.2f}s ({read_mbps:.1f} MB/s)")
        print(f"  ✓ Integrity: {'OK' if integrity_ok else 'FAILED'}")
    
    async def run_all_tests(self):
        """Ejecuta todas las pruebas de rendimiento"""
        print("🚀 Starting performance test suite...")
        
        self.setup()
        
        try:
            await self.test_file_write_performance(100, 1024)
            await self.test_file_read_performance(100)
            await self.test_concurrent_access(20, 5)
            await self.test_large_file_handling(5)
            
        finally:
            self.teardown()
        
        self.print_summary()
    
    def print_summary(self):
        """Imprime resumen de resultados"""
        print("\n" + "="*60)
        print("📊 PERFORMANCE TEST SUMMARY")
        print("="*60)
        
        for test_name, results in self.results.items():
            print(f"\n{test_name.upper().replace('_', ' ')}:")
            for key, value in results.items():
                if isinstance(value, float):
                    if 'time' in key or 'latency' in key:
                        print(f"  {key}: {value:.3f}s")
                    elif 'mbps' in key or 'per_second' in key:
                        print(f"  {key}: {value:.2f}")
                    else:
                        print(f"  {key}: {value:.2f}")
                else:
                    print(f"  {key}: {value}")


class NetworkPerformanceTests:
    """Pruebas de rendimiento de red"""
    
    async def test_http_api_performance(self, base_url="http://localhost:8080", num_requests=100):
        """Prueba rendimiento de la API HTTP"""
        print(f"🌐 Testing HTTP API performance: {num_requests} requests to {base_url}")
        
        async def make_request(session, url):
            """Realiza una petición HTTP"""
            start = time.time()
            try:
                async with session.get(url) as response:
                    await response.read()
                    return time.time() - start, response.status
            except Exception as e:
                return time.time() - start, -1
        
        start_time = time.time()
        
        async with aiohttp.ClientSession() as session:
            tasks = []
            for _ in range(num_requests):
                task = make_request(session, f"{base_url}/api/files")
                tasks.append(task)
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
        
        end_time = time.time()
        total_time = end_time - start_time
        
        # Procesar resultados
        latencies = []
        successful_requests = 0
        
        for result in results:
            if isinstance(result, tuple):
                latency, status = result
                latencies.append(latency)
                if status == 200:
                    successful_requests += 1
        
        if latencies:
            avg_latency = statistics.mean(latencies)
            p95_latency = statistics.quantiles(latencies, n=20)[18] if len(latencies) >= 20 else max(latencies)
            requests_per_second = num_requests / total_time
            success_rate = successful_requests / num_requests
            
            print(f"  ✓ Total time: {total_time:.2f}s")
            print(f"  ✓ Requests/sec: {requests_per_second:.1f}")
            print(f"  ✓ Success rate: {success_rate:.1%}")
            print(f"  ✓ Avg latency: {avg_latency*1000:.1f}ms")
            print(f"  ✓ P95 latency: {p95_latency*1000:.1f}ms")
        else:
            print("  ❌ No successful requests")


async def run_performance_tests():
    """Ejecuta todas las pruebas de rendimiento"""
    # Pruebas del sistema de archivos
    perf_tests = PerformanceTests()
    await perf_tests.run_all_tests()
    
    # Pruebas de red (si hay un servidor ejecutándose)
    print("\n" + "="*60)
    print("🌐 NETWORK PERFORMANCE TESTS")
    print("="*60)
    
    network_tests = NetworkPerformanceTests()
    try:
        await network_tests.test_http_api_performance()
    except Exception as e:
        print(f"❌ Network tests failed (server may not be running): {e}")


if __name__ == "__main__":
    asyncio.run(run_performance_tests())