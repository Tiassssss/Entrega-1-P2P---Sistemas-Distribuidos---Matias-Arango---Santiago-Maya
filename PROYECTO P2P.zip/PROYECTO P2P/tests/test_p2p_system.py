"""
Suite de pruebas para el sistema P2P
"""
import asyncio
import pytest
import tempfile
import shutil
import os
import json
from pathlib import Path
import sys

# Agregar el directorio raíz al path
sys.path.append(str(Path(__file__).parent.parent))

from src.pservidor.file_manager.file_manager import FileManager, EchoService, DummyService
from src.common.models import FileInfo, PeerInfo, PeerStatus
from src.common.utils import calculate_file_hash
from src.config.config_manager import ConfigManager
from datetime import datetime


class TestFileManager:
    """Pruebas para el gestor de archivos"""
    
    def setup_method(self):
        """Configuración para cada prueba"""
        self.temp_dir = tempfile.mkdtemp()
        self.peer_id = "test_peer"
        self.file_manager = FileManager(self.temp_dir, self.peer_id)
    
    def teardown_method(self):
        """Limpieza después de cada prueba"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    @pytest.mark.asyncio
    async def test_write_and_read_file(self):
        """Prueba escritura y lectura de archivos"""
        filename = "test.txt"
        content = b"Hello, P2P World!"
        
        # Escribir archivo
        file_info = await self.file_manager.write_file(filename, content)
        
        assert file_info.filename == filename
        assert file_info.size == len(content)
        assert file_info.peer_id == self.peer_id
        
        # Leer archivo
        read_content = await self.file_manager.read_file(filename)
        assert read_content == content
    
    @pytest.mark.asyncio
    async def test_scan_files(self):
        """Prueba escaneo de archivos"""
        # Crear archivos de prueba
        test_files = {
            "file1.txt": b"Content 1",
            "file2.txt": b"Content 2",
            "file3.pdf": b"PDF content"
        }
        
        for filename, content in test_files.items():
            await self.file_manager.write_file(filename, content)
        
        # Escanear archivos
        files = await self.file_manager.scan_files()
        
        assert len(files) == len(test_files)
        filenames = {f.filename for f in files}
        assert filenames == set(test_files.keys())
    
    @pytest.mark.asyncio
    async def test_search_files(self):
        """Prueba búsqueda de archivos"""
        # Crear archivos de prueba
        await self.file_manager.write_file("document.txt", b"content")
        await self.file_manager.write_file("image.jpg", b"image data")
        await self.file_manager.write_file("report.pdf", b"report content")
        
        # Buscar archivos
        results = self.file_manager.search_files("doc")
        assert len(results) == 1
        assert results[0].filename == "document.txt"
        
        results = self.file_manager.search_files("txt")
        assert len(results) == 1
        
        results = self.file_manager.search_files("nonexistent")
        assert len(results) == 0
    
    @pytest.mark.asyncio
    async def test_file_integrity(self):
        """Prueba verificación de integridad de archivos"""
        filename = "integrity_test.txt"
        content = b"Test content for integrity check"
        
        # Escribir archivo
        file_info = await self.file_manager.write_file(filename, content)
        
        # Verificar integridad
        is_valid = await self.file_manager.validate_file_integrity(filename)
        assert is_valid is True
        
        # Corromper archivo
        file_path = Path(self.temp_dir) / filename
        with open(file_path, 'w') as f:
            f.write("corrupted content")
        
        # Verificar que detecta corrupción
        is_valid = await self.file_manager.validate_file_integrity(filename)
        assert is_valid is False


class TestEchoService:
    """Pruebas para el servicio ECO"""
    
    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.file_manager = FileManager(self.temp_dir, "test_peer")
        self.echo_service = EchoService(self.file_manager)
    
    def teardown_method(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    @pytest.mark.asyncio
    async def test_echo_file(self):
        """Prueba que el servicio ECO retorna los mismos datos"""
        filename = "echo_test.txt"
        test_data = b"Echo service test data"
        
        result = await self.echo_service.echo_file(filename, test_data)
        
        assert result == test_data


class TestDummyService:
    """Pruebas para el servicio DUMMY"""
    
    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.file_manager = FileManager(self.temp_dir, "test_peer")
        self.dummy_service = DummyService(self.file_manager)
    
    def teardown_method(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    @pytest.mark.asyncio
    async def test_generate_dummy_file(self):
        """Prueba generación de archivos dummy"""
        filename = "dummy_test.txt"
        size = 1024  # 1KB
        
        result = await self.dummy_service.generate_dummy_file(filename, size)
        
        assert len(result) == size
        assert result.startswith(b"DUMMY_DATA_")
    
    @pytest.mark.asyncio
    async def test_create_test_files(self):
        """Prueba creación de archivos de test"""
        test_files = await self.dummy_service.create_test_files(3)
        
        assert len(test_files) == 3
        for i, file_info in enumerate(test_files):
            assert file_info.filename == f"test_file_{i}.txt"
            assert file_info.size > 0


class TestConfigManager:
    """Pruebas para el gestor de configuración"""
    
    def test_load_config(self):
        """Prueba carga de configuración desde archivo"""
        # Crear configuración temporal
        config_data = {
            "peer_id": "test_peer",
            "network": {
                "listen_ip": "0.0.0.0",
                "listen_port": 8080,
                "rpc_port": 8081,
                "max_connections": 50
            },
            "storage": {
                "shared_directory": "./test_shared",
                "max_file_size": "100MB",
                "allowed_extensions": [".txt", ".pdf"]
            },
            "peers": {
                "bootstrap_peers": ["http://localhost:8080"],
                "backup_peers": []
            },
            "security": {
                "enable_auth": False,
                "api_key": None
            },
            "logging": {
                "level": "INFO",
                "file": "test.log"
            }
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(config_data, f)
            config_path = f.name
        
        try:
            # Cargar configuración
            config_manager = ConfigManager(config_path)
            config = config_manager.load_config()
            
            assert config.peer_id == "test_peer"
            assert config.network.listen_port == 8080
            assert config.storage.shared_directory == "./test_shared"
            assert len(config.peers.bootstrap_peers) == 1
            
        finally:
            os.unlink(config_path)


class TestP2PIntegration:
    """Pruebas de integración del sistema P2P"""
    
    @pytest.mark.asyncio
    async def test_file_transfer_simulation(self):
        """Simula transferencia de archivos entre peers"""
        # Crear dos directorios temporales para simular peers
        peer1_dir = tempfile.mkdtemp()
        peer2_dir = tempfile.mkdtemp()
        
        try:
            # Crear gestores de archivos para cada peer
            peer1_manager = FileManager(peer1_dir, "peer1")
            peer2_manager = FileManager(peer2_dir, "peer2")
            
            # Peer 1 crea un archivo
            filename = "shared_file.txt"
            content = b"This file is shared between peers"
            
            file_info = await peer1_manager.write_file(filename, content)
            
            # Simular transferencia: Peer 1 -> Peer 2
            transferred_content = await peer1_manager.read_file(filename)
            await peer2_manager.write_file(filename, transferred_content)
            
            # Verificar que el archivo se transfirió correctamente
            peer2_content = await peer2_manager.read_file(filename)
            assert peer2_content == content
            
            # Verificar integridad
            peer1_files = peer1_manager.get_files()
            peer2_files = peer2_manager.get_files()
            
            assert len(peer1_files) == 1
            assert len(peer2_files) == 1
            
            assert peer1_files[0].hash == peer2_files[0].hash
            
        finally:
            shutil.rmtree(peer1_dir, ignore_errors=True)
            shutil.rmtree(peer2_dir, ignore_errors=True)
    
    @pytest.mark.asyncio
    async def test_concurrent_operations(self):
        """Prueba operaciones concurrentes en el gestor de archivos"""
        temp_dir = tempfile.mkdtemp()
        
        try:
            file_manager = FileManager(temp_dir, "test_peer")
            
            # Crear múltiples archivos concurrentemente
            tasks = []
            for i in range(10):
                filename = f"concurrent_file_{i}.txt"
                content = f"Content for file {i}".encode()
                task = file_manager.write_file(filename, content)
                tasks.append(task)
            
            # Esperar que todos se completen
            results = await asyncio.gather(*tasks)
            
            assert len(results) == 10
            
            # Verificar que todos los archivos se crearon
            files = await file_manager.scan_files()
            assert len(files) == 10
            
            # Leer archivos concurrentemente
            read_tasks = []
            for i in range(10):
                filename = f"concurrent_file_{i}.txt"
                task = file_manager.read_file(filename)
                read_tasks.append(task)
            
            read_results = await asyncio.gather(*read_tasks)
            
            assert len(read_results) == 10
            for i, content in enumerate(read_results):
                expected = f"Content for file {i}".encode()
                assert content == expected
                
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)


class TestNetworkSimulation:
    """Pruebas de simulación de red"""
    
    def test_peer_discovery_simulation(self):
        """Simula descubrimiento de peers en la red"""
        # Crear información de peers de prueba
        peers = {}
        
        for i in range(5):
            peer_id = f"peer_{i}"
            peer_info = PeerInfo(
                peer_id=peer_id,
                address=f"192.168.1.{10 + i}",
                port=8080 + i,
                rpc_port=8081 + i,
                status=PeerStatus.ACTIVE,
                files_count=i * 2,
                last_seen=datetime.now()
            )
            peers[peer_id] = peer_info
        
        # Simular que cada peer conoce a algunos otros
        peer_networks = {
            "peer_0": ["peer_1", "peer_2"],
            "peer_1": ["peer_0", "peer_2", "peer_3"],
            "peer_2": ["peer_0", "peer_1", "peer_4"],
            "peer_3": ["peer_1", "peer_4"],
            "peer_4": ["peer_2", "peer_3"]
        }
        
        # Verificar conectividad de la red
        def can_reach_all_peers(start_peer, visited=None):
            if visited is None:
                visited = set()
            
            if start_peer in visited:
                return visited
            
            visited.add(start_peer)
            
            for neighbor in peer_networks.get(start_peer, []):
                can_reach_all_peers(neighbor, visited)
            
            return visited
        
        # Verificar que desde peer_0 se puede llegar a todos
        reachable = can_reach_all_peers("peer_0")
        assert len(reachable) == 5  # Todos los peers son alcanzables
    
    def test_file_distribution_simulation(self):
        """Simula distribución de archivos en la red"""
        # Simular archivos distribuidos entre peers
        peer_files = {
            "peer_1": ["file_a.txt", "file_b.pdf", "shared.doc"],
            "peer_2": ["file_c.jpg", "shared.doc", "unique.zip"],
            "peer_3": ["file_d.mp3", "file_e.txt"],
            "peer_4": ["shared.doc", "file_f.pdf"]
        }
        
        # Función para buscar archivo en la red
        def search_file_in_network(filename):
            locations = []
            for peer_id, files in peer_files.items():
                if filename in files:
                    locations.append(peer_id)
            return locations
        
        # Pruebas de búsqueda
        locations = search_file_in_network("shared.doc")
        assert len(locations) == 3  # Archivo está en 3 peers
        
        locations = search_file_in_network("unique.zip")
        assert len(locations) == 1  # Archivo único
        assert locations[0] == "peer_2"
        
        locations = search_file_in_network("nonexistent.txt")
        assert len(locations) == 0  # Archivo no existe


# Script para ejecutar todas las pruebas
async def run_all_tests():
    """Ejecuta todas las pruebas del sistema"""
    print("🧪 Ejecutando suite de pruebas P2P...")
    
    # Pruebas síncronas
    sync_test_classes = [
        TestConfigManager,
        TestNetworkSimulation
    ]
    
    for test_class in sync_test_classes:
        print(f"\n📋 Ejecutando {test_class.__name__}...")
        test_instance = test_class()
        
        for method_name in dir(test_instance):
            if method_name.startswith('test_'):
                print(f"  ✓ {method_name}")
                method = getattr(test_instance, method_name)
                method()
    
    # Pruebas asíncronas
    async_test_classes = [
        TestFileManager,
        TestEchoService,
        TestDummyService,
        TestP2PIntegration
    ]
    
    for test_class in async_test_classes:
        print(f"\n📋 Ejecutando {test_class.__name__}...")
        test_instance = test_class()
        
        for method_name in dir(test_instance):
            if method_name.startswith('test_'):
                print(f"  ✓ {method_name}")
                
                # Setup
                if hasattr(test_instance, 'setup_method'):
                    test_instance.setup_method()
                
                try:
                    # Ejecutar prueba
                    method = getattr(test_instance, method_name)
                    await method()
                finally:
                    # Teardown
                    if hasattr(test_instance, 'teardown_method'):
                        test_instance.teardown_method()
    
    print("\n✅ Todas las pruebas completadas exitosamente!")


if __name__ == "__main__":
    asyncio.run(run_all_tests())