#!/usr/bin/env python3
"""
Cliente de línea de comandos para interactuar con la red P2P
"""

import asyncio
import argparse
import json
import sys
from pathlib import Path

# Agregar el directorio raíz al path
sys.path.append(str(Path(__file__).parent))

from src.pcliente.rest_client import RestClient
from src.common.models import PeerInfo, PeerStatus
from datetime import datetime


class P2PCliClient:
    """Cliente CLI para el sistema P2P"""
    
    def __init__(self, peer_url: str = "http://localhost:8080"):
        self.peer_url = peer_url
        self.rest_client = RestClient()
        
        # Crear PeerInfo para el peer objetivo
        if peer_url.startswith('http://'):
            address_port = peer_url[7:]
            if ':' in address_port:
                address, port_str = address_port.split(':')
                port = int(port_str)
            else:
                address = address_port
                port = 80
        
        self.peer_info = PeerInfo(
            peer_id="target_peer",
            address=address,
            port=port,
            rpc_port=port + 1,
            status=PeerStatus.ACTIVE,
            files_count=0,
            last_seen=datetime.now()
        )
    
    async def list_files(self, query: str = None):
        """Lista archivos disponibles en el peer"""
        try:
            files = await self.rest_client.list_files_on_peer(self.peer_info, query)
            
            if not files:
                print("No files found")
                return
            
            print(f"Found {len(files)} files:")
            print("-" * 60)
            for file_info in files:
                size_mb = file_info.size / (1024 * 1024)
                print(f"📄 {file_info.filename}")
                print(f"   Size: {size_mb:.2f} MB")
                print(f"   Hash: {file_info.hash[:16]}...")
                print(f"   Peer: {file_info.peer_id}")
                print()
        
        except Exception as e:
            print(f"Error listing files: {e}")
    
    async def download_file(self, filename: str, output_path: str = None):
        """Descarga un archivo específico"""
        try:
            print(f"Downloading {filename}...")
            
            data = await self.rest_client.download_file_from_peer(self.peer_info, filename)
            
            if output_path is None:
                output_path = filename
            
            with open(output_path, 'wb') as f:
                f.write(data)
            
            size_mb = len(data) / (1024 * 1024)
            print(f"✅ Downloaded {filename} ({size_mb:.2f} MB) to {output_path}")
        
        except Exception as e:
            print(f"❌ Error downloading {filename}: {e}")
    
    async def upload_file(self, file_path: str):
        """Sube un archivo al peer"""
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                print(f"❌ File not found: {file_path}")
                return
            
            print(f"Uploading {file_path.name}...")
            
            with open(file_path, 'rb') as f:
                data = f.read()
            
            success = await self.rest_client.upload_file_to_peer(
                self.peer_info, file_path.name, data
            )
            
            if success:
                size_mb = len(data) / (1024 * 1024)
                print(f"✅ Uploaded {file_path.name} ({size_mb:.2f} MB)")
            else:
                print(f"❌ Failed to upload {file_path.name}")
        
        except Exception as e:
            print(f"❌ Error uploading {file_path}: {e}")
    
    async def search_files(self, query: str):
        """Busca archivos en el peer"""
        try:
            files = await self.rest_client.search_files_on_peer(self.peer_info, query)
            
            if not files:
                print(f"No files found matching '{query}'")
                return
            
            print(f"Found {len(files)} files matching '{query}':")
            print("-" * 60)
            for file_info in files:
                size_mb = file_info.size / (1024 * 1024)
                print(f"📄 {file_info.filename} ({size_mb:.2f} MB)")
        
        except Exception as e:
            print(f"Error searching files: {e}")
    
    async def get_peer_info(self):
        """Obtiene información del peer"""
        try:
            info = await self.rest_client.get_peer_info(self.peer_info)
            
            print("Peer Information:")
            print("-" * 30)
            print(json.dumps(info, indent=2))
        
        except Exception as e:
            print(f"Error getting peer info: {e}")
    
    async def list_peers(self):
        """Lista peers conocidos"""
        try:
            peers = await self.rest_client.get_peers_from_peer(self.peer_info)
            
            if not peers:
                print("No peers found")
                return
            
            print(f"Found {len(peers)} peers:")
            print("-" * 50)
            for peer in peers:
                print(f"🌐 {peer.peer_id}")
                print(f"   Address: {peer.url}")
                print(f"   Status: {peer.status.value}")
                print(f"   Files: {peer.files_count}")
                print()
        
        except Exception as e:
            print(f"Error listing peers: {e}")
    
    async def echo_test(self, filename: str):
        """Prueba el servicio ECO"""
        try:
            test_data = b"Hello, P2P Echo Service! This is a test message."
            
            print(f"Testing ECHO service with {filename}...")
            
            result = await self.rest_client.echo_file_with_peer(
                self.peer_info, filename, test_data
            )
            
            if result == test_data:
                print("✅ ECHO service test passed")
            else:
                print("❌ ECHO service test failed - data mismatch")
        
        except Exception as e:
            print(f"❌ ECHO service test failed: {e}")
    
    async def dummy_test(self, filename: str, size: int):
        """Prueba el servicio DUMMY"""
        try:
            print(f"Testing DUMMY service - generating {filename} ({size} bytes)...")
            
            result = await self.rest_client.generate_dummy_file_from_peer(
                self.peer_info, filename, size
            )
            
            if len(result) == size:
                print(f"✅ DUMMY service test passed - generated {len(result)} bytes")
                
                # Guardar archivo dummy
                with open(f"dummy_{filename}", 'wb') as f:
                    f.write(result)
                print(f"   Saved as dummy_{filename}")
            else:
                print(f"❌ DUMMY service test failed - size mismatch")
        
        except Exception as e:
            print(f"❌ DUMMY service test failed: {e}")


async def main():
    parser = argparse.ArgumentParser(description='P2P CLI Client')
    parser.add_argument('--peer', default='http://localhost:8080', 
                       help='Peer URL (default: http://localhost:8080)')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # List files command
    list_parser = subparsers.add_parser('list', help='List files')
    list_parser.add_argument('--query', help='Search query')
    
    # Download command
    download_parser = subparsers.add_parser('download', help='Download file')
    download_parser.add_argument('filename', help='File to download')
    download_parser.add_argument('--output', help='Output path')
    
    # Upload command
    upload_parser = subparsers.add_parser('upload', help='Upload file')
    upload_parser.add_argument('file_path', help='File to upload')
    
    # Search command
    search_parser = subparsers.add_parser('search', help='Search files')
    search_parser.add_argument('query', help='Search query')
    
    # Info command
    subparsers.add_parser('info', help='Get peer info')
    
    # Peers command
    subparsers.add_parser('peers', help='List known peers')
    
    # Echo test command
    echo_parser = subparsers.add_parser('echo', help='Test ECHO service')
    echo_parser.add_argument('filename', help='Test filename')
    
    # Dummy test command
    dummy_parser = subparsers.add_parser('dummy', help='Test DUMMY service')
    dummy_parser.add_argument('filename', help='Test filename')
    dummy_parser.add_argument('size', type=int, help='File size in bytes')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    client = P2PCliClient(args.peer)
    
    try:
        if args.command == 'list':
            await client.list_files(args.query)
        elif args.command == 'download':
            await client.download_file(args.filename, args.output)
        elif args.command == 'upload':
            await client.upload_file(args.file_path)
        elif args.command == 'search':
            await client.search_files(args.query)
        elif args.command == 'info':
            await client.get_peer_info()
        elif args.command == 'peers':
            await client.list_peers()
        elif args.command == 'echo':
            await client.echo_test(args.filename)
        elif args.command == 'dummy':
            await client.dummy_test(args.filename, args.size)
    
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    asyncio.run(main())