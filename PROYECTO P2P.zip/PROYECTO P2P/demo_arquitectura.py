#!/usr/bin/env python3
"""
Demostración de la Arquitectura P2P según el Diagrama
Implementa exactamente el flujo mostrado en la imagen adjunta

Estructura:
- PEER MAESTRO (directorio/localización)
- PEER 1, 2, 3 (peers distribuidos)
- Cada peer: Pcliente + Pservidor + REST + gRPC
"""
import asyncio
import sys
import time
from pathlib import Path

# Agregar el directorio raíz al path
sys.path.append(str(Path(__file__).parent))

from src.p2p_node import P2PNode, BootstrapManager
from src.config.config_manager import config_manager


class ArchitectureDemo:
    """Demostración de la arquitectura según el diagrama"""
    
    def __init__(self):
        self.bootstrap_manager = BootstrapManager()
        self.peer_maestro = None
        self.peers = {}
        
    async def setup_peer_maestro(self):
        """Configura el PEER MAESTRO (directorio/localización)"""
        print("\n🎯 CONFIGURANDO PEER MAESTRO (Directorio/Localización)")
        print("=" * 60)
        
        # Configuración del peer maestro
        maestro_config = {
            "peer_id": "PEER_MAESTRO",
            "network": {
                "listen_ip": "0.0.0.0",
                "listen_port": 8080,
                "rpc_port": 8081,
                "max_connections": 100
            },
            "storage": {
                "shared_directory": "./shared_files_maestro",
                "max_file_size": "100MB",
                "allowed_extensions": [".txt", ".pdf", ".jpg", ".png", ".bin"]
            },
            "peers": {
                "bootstrap_peers": [],  # Es el peer maestro
                "backup_peers": []
            },
            "logging": {
                "level": "INFO",
                "file": "logs/peer_maestro.log"
            }
        }
        
        # Crear directorio
        Path("./shared_files_maestro").mkdir(exist_ok=True)
        
        # Crear algunos archivos en el peer maestro
        with open("./shared_files_maestro/directorio_central.txt", "w") as f:
            f.write("Archivo central del peer maestro - DIRECTORIO/LOCALIZACIÓN")
        with open("./shared_files_maestro/maestro_data.pdf", "w") as f:
            f.write("PDF del peer maestro para compartir")
        
        # Guardar configuración
        import json
        with open("/tmp/peer_maestro_config.json", "w") as f:
            json.dump(maestro_config, f, indent=2)
        
        # Crear e iniciar peer maestro
        self.peer_maestro = P2PNode("/tmp/peer_maestro_config.json")
        
        print("✅ Peer Maestro configurado")
        print(f"   - Pcliente: Consulta de peers y localización")
        print(f"   - Pservidor: REST (/files, /search) + gRPC (Upload/Download)")
        print(f"   - Puerto REST: 8080")
        print(f"   - Puerto gRPC: 8081")
        
        return self.peer_maestro
    
    async def setup_peer_distribuido(self, peer_num: int):
        """Configura un PEER distribuido (1, 2, 3)"""
        base_port = 8080 + (peer_num * 2)
        peer_id = f"PEER_{peer_num}"
        
        print(f"\n📡 CONFIGURANDO {peer_id}")
        print("-" * 40)
        
        # Configuración del peer
        peer_config = {
            "peer_id": peer_id,
            "network": {
                "listen_ip": "0.0.0.0", 
                "listen_port": base_port,
                "rpc_port": base_port + 1,
                "max_connections": 50
            },
            "storage": {
                "shared_directory": f"./shared_files_peer{peer_num}",
                "max_file_size": "100MB",
                "allowed_extensions": [".txt", ".pdf", ".jpg", ".png", ".bin"]
            },
            "peers": {
                "bootstrap_peers": ["http://127.0.0.1:8080"],  # Conectar al peer maestro
                "backup_peers": []
            },
            "logging": {
                "level": "INFO",
                "file": f"logs/peer_{peer_num}.log"
            }
        }
        
        # Crear directorio
        Path(f"./shared_files_peer{peer_num}").mkdir(exist_ok=True)
        
        # Crear archivos específicos en cada peer
        with open(f"./shared_files_peer{peer_num}/archivo_peer{peer_num}.txt", "w") as f:
            f.write(f"Archivo específico del PEER {peer_num}")
        with open(f"./shared_files_peer{peer_num}/data_peer{peer_num}.pdf", "w") as f:
            f.write(f"PDF del PEER {peer_num}")
        
        # Guardar configuración
        import json
        with open(f"/tmp/peer_{peer_num}_config.json", "w") as f:
            json.dump(peer_config, f, indent=2)
        
        # Crear peer
        peer = P2PNode(f"/tmp/peer_{peer_num}_config.json")
        self.peers[peer_id] = peer
        
        print(f"✅ {peer_id} configurado")
        print(f"   - Pcliente: Consulta maestro, consulta peers, solicita upload/download")
        print(f"   - Pservidor: REST (/files, /search) + gRPC (Upload/Download)")
        print(f"   - Puerto REST: {base_port}")
        print(f"   - Puerto gRPC: {base_port + 1}")
        
        return peer
    
    async def demostrar_flujo_consulta_maestro(self):
        """Demuestra: Pcliente -> Consulta maestro"""
        print("\n🔍 DEMOSTRACIÓN: Pcliente -> Consulta maestro")
        print("=" * 50)
        
        # Desde PEER_1, consultar al maestro
        peer1 = self.peers["PEER_1"]
        
        print("📤 PEER_1 consulta al PEER_MAESTRO...")
        
        # Buscar en el peer maestro
        results = await peer1.search_files("directorio")
        
        print("📥 Respuesta del PEER_MAESTRO:")
        for result in results:
            print(f"   📄 {result.filename} ({result.size} bytes) - desde {result.peer_id}")
    
    async def demostrar_flujo_consulta_peers(self):
        """Demuestra: Pcliente -> Consulta Peers"""
        print("\n🌐 DEMOSTRACIÓN: Pcliente -> Consulta Peers")
        print("=" * 50)
        
        # Desde PEER_2, consultar a todos los peers
        peer2 = self.peers["PEER_2"]
        
        print("📤 PEER_2 consulta a todos los peers en la red...")
        
        # Búsqueda distribuida
        results = await peer2.search_files("peer")
        
        print("📥 Respuestas de todos los peers:")
        for result in results:
            print(f"   📄 {result.filename} ({result.size} bytes) - desde {result.peer_id}")
    
    async def demostrar_flujo_upload(self):
        """Demuestra: Pcliente -> Solicita Upload"""
        print("\n📤 DEMOSTRACIÓN: Pcliente -> Solicita Upload")
        print("=" * 50)
        
        # PEER_3 sube un archivo
        peer3 = self.peers["PEER_3"]
        
        print("📤 PEER_3 subiendo archivo...")
        
        # Crear archivo para subir
        upload_data = "Archivo subido por PEER_3 via Pcliente".encode()
        
        # Upload usando el componente Pcliente
        result = await peer3.upload_local_file("upload_desde_peer3.txt", upload_data)
        
        print(f"✅ Upload completado: {result}")
    
    async def demostrar_flujo_download(self):
        """Demuestra: Pcliente -> Solicita Download"""
        print("\n📥 DEMOSTRACIÓN: Pcliente -> Solicita Download")
        print("=" * 50)
        
        # PEER_1 descarga archivo del PEER_3
        peer1 = self.peers["PEER_1"]
        
        print("📥 PEER_1 descargando archivo de PEER_3...")
        
        # Download usando el componente Pcliente
        try:
            data = await peer1.download_file("upload_desde_peer3.txt")
            print(f"✅ Download completado: {len(data)} bytes")
            print(f"   Contenido: {data.decode()[:50]}...")
        except Exception as e:
            print(f"❌ Error en download: {e}")
    
    async def demostrar_rest_endpoints(self):
        """Demuestra: Pservidor -> REST (/files, /search)"""
        print("\n🌐 DEMOSTRACIÓN: Pservidor -> REST (/files, /search)")
        print("=" * 50)
        
        import aiohttp
        
        print("🔗 Consultando endpoints REST...")
        
        async with aiohttp.ClientSession() as session:
            # GET /api/files del PEER_MAESTRO
            async with session.get("http://localhost:8080/api/files") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    print(f"✅ PEER_MAESTRO /api/files: {len(data.get('data', []))} archivos")
                
            # GET /api/search del PEER_1  
            async with session.get("http://localhost:8082/api/search?q=peer") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    print(f"✅ PEER_1 /api/search: {len(data.get('data', []))} resultados")
    
    async def demostrar_grpc_endpoints(self):
        """Demuestra: Pservidor -> gRPC (Upload/Download)"""
        print("\n⚡ DEMOSTRACIÓN: Pservidor -> gRPC (Upload/Download)")
        print("=" * 50)
        
        # Usar RPC client para comunicación directa
        from src.pcliente.rpc_client import RPCClient
        
        rpc_client = RPCClient()
        
        # Información del PEER_MAESTRO
        maestro_info = self.peer_maestro.local_peer_info
        
        print("⚡ Conectando via gRPC al PEER_MAESTRO...")
        
        try:
            # Búsqueda via gRPC
            results = await rpc_client.search_file_on_peer(maestro_info, "directorio", "DEMO_CLIENT")
            print(f"✅ gRPC Search: {len(results)} resultados")
            
            if results:
                # Download via gRPC
                first_file = results[0].filename
                file_data = await rpc_client.download_file_from_peer(maestro_info, first_file)
                print(f"✅ gRPC Download: {len(file_data)} bytes de '{first_file}'")
        
        except Exception as e:
            print(f"❌ Error gRPC: {e}")
    
    async def run_full_demo(self):
        """Ejecuta la demostración completa de la arquitectura"""
        print("\n" + "="*80)
        print("🎯 DEMOSTRACIÓN ARQUITECTURA P2P - SEGÚN DIAGRAMA")
        print("="*80)
        print("Estructura: PEER MAESTRO + PEER 1,2,3")
        print("Cada peer: Pcliente + Pservidor + REST + gRPC")
        print("="*80)
        
        try:
            # 1. Configurar PEER MAESTRO (directorio/localización)
            await self.setup_peer_maestro()
            
            # 2. Configurar PEERS distribuidos (1, 2, 3)
            for i in range(1, 4):
                await self.setup_peer_distribuido(i)
            
            print("\n🚀 INICIANDO TODOS LOS PEERS...")
            print("=" * 40)
            
            # 3. Iniciar PEER MAESTRO primero
            maestro_task = asyncio.create_task(self.peer_maestro.start())
            await asyncio.sleep(2)  # Esperar que inicie
            
            # 4. Iniciar peers distribuidos
            peer_tasks = []
            for peer in self.peers.values():
                task = asyncio.create_task(peer.start())
                peer_tasks.append(task)
                await asyncio.sleep(1)  # Esperar entre inicios
            
            # 5. Esperar estabilización de la red
            print("⏳ Esperando estabilización de la red...")
            await asyncio.sleep(5)
            
            # 6. Ejecutar demostraciones de flujos
            await self.demostrar_flujo_consulta_maestro()
            await asyncio.sleep(1)
            
            await self.demostrar_flujo_consulta_peers()
            await asyncio.sleep(1)
            
            await self.demostrar_flujo_upload()
            await asyncio.sleep(1)
            
            await self.demostrar_flujo_download()
            await asyncio.sleep(1)
            
            await self.demostrar_rest_endpoints()
            await asyncio.sleep(1)
            
            await self.demostrar_grpc_endpoints()
            
            print("\n" + "="*80)
            print("✅ DEMOSTRACIÓN COMPLETADA - ARQUITECTURA FUNCIONANDO")
            print("="*80)
            print("✅ PEER MAESTRO: Directorio/Localización funcionando")
            print("✅ PEERS 1,2,3: Comunicación distribuida funcionando")
            print("✅ Pcliente: Consultas y solicitudes funcionando")
            print("✅ Pservidor: REST + gRPC funcionando")
            print("="*80)
            
            # Mantener activo por un tiempo para pruebas manuales
            print("\n🔧 Red P2P activa. Pruebas disponibles:")
            print("   curl http://localhost:8080/api/files  # PEER MAESTRO")
            print("   curl http://localhost:8082/api/files  # PEER 1")
            print("   curl http://localhost:8084/api/files  # PEER 2") 
            print("   curl http://localhost:8086/api/files  # PEER 3")
            print("\nPresiona Ctrl+C para terminar...")
            
            # Esperar indefinidamente
            await asyncio.gather(*peer_tasks, maestro_task, return_exceptions=True)
            
        except KeyboardInterrupt:
            print("\n🛑 Deteniendo demostración...")
        except Exception as e:
            print(f"\n❌ Error en demostración: {e}")
        finally:
            # Limpiar
            if self.peer_maestro:
                await self.peer_maestro.stop()
            for peer in self.peers.values():
                await peer.stop()


async def main():
    """Función principal"""
    demo = ArchitectureDemo()
    await demo.run_full_demo()


if __name__ == "__main__":
    # Crear directorios necesarios
    Path("logs").mkdir(exist_ok=True)
    
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nDemo terminada por el usuario")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)